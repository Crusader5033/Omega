﻿using Omega.Controller;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Omega.View
{
    public partial class ExportXMLForm : Form
    {
        private ExportXMLController exportController;

        public ExportXMLForm()
        {
            InitializeComponent();
            exportController = new ExportXMLController();
        }

        private void RoleBtn_Click(object sender, EventArgs e)
        {
            try
            {
                // Vytvořte novou instanci SaveFileDialog
                SaveFileDialog saveFileDialog = new SaveFileDialog();

                // Nastavte vlastnosti dialogu pro uložení souboru
                saveFileDialog.Filter = "XML soubory (*.xml)|*.xml"; // Nastavte filtr pro zobrazení pouze XML souborů
                saveFileDialog.FileName = "dataRole.xml"; // Výchozí název souboru
                saveFileDialog.Title = "Exportovat data rolí"; // Nadpis dialogu

                // Zobrazit dialog pro uložení souboru
                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    string filePath = saveFileDialog.FileName; // Získejte vybranou cestu k souboru

                    // Exportovat data do XML pomocí vybrané cesty k souboru
                    exportController.ExportToXMLRole(filePath);

                    // Zobrazit úspěšnou zprávu
                    MessageBox.Show("Data úspěšně exportována.", "Úspěch", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                // Zobrazit chybovou zprávu
                MessageBox.Show($"Chyba při exportu dat: {ex.Message}", "Chyba", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ExportSluzbyBtn_Click(object sender, EventArgs e)
        {
            try
            {
                // Vytvořte novou instanci SaveFileDialog
                SaveFileDialog saveFileDialog = new SaveFileDialog();

                // Nastavte vlastnosti dialogu pro uložení souboru
                saveFileDialog.Filter = "XML soubory (*.xml)|*.xml"; // Nastavte filtr pro zobrazení pouze XML souborů
                saveFileDialog.FileName = "dataSluzby.xml"; // Výchozí název souboru
                saveFileDialog.Title = "Exportovat data služeb"; // Nadpis dialogu

                // Zobrazit dialog pro uložení souboru
                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    string filePath = saveFileDialog.FileName; // Získejte vybranou cestu k souboru

                    // Exportovat data do XML pomocí vybrané cesty k souboru
                    exportController.ExportToXMLSluzby(filePath);

                    // Zobrazit úspěšnou zprávu
                    MessageBox.Show("Data úspěšně exportována.", "Úspěch", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                // Zobrazit chybovou zprávu
                MessageBox.Show($"Chyba při exportu dat: {ex.Message}", "Chyba", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void SpecializaceBtn_Click(object sender, EventArgs e)
        {
            try
            {
                // Vytvořte novou instanci SaveFileDialog
                SaveFileDialog saveFileDialog = new SaveFileDialog();

                // Nastavte vlastnosti dialogu pro uložení souboru
                saveFileDialog.Filter = "XML soubory (*.xml)|*.xml"; // Nastavte filtr pro zobrazení pouze XML souborů
                saveFileDialog.FileName = "dataSpecializace.xml"; // Výchozí název souboru
                saveFileDialog.Title = "Exportovat data specializací"; // Nadpis dialogu

                // Zobrazit dialog pro uložení souboru
                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    string filePath = saveFileDialog.FileName; // Získejte vybranou cestu k souboru

                    // Exportovat data do XML pomocí vybrané cesty k souboru
                    exportController.ExportToXMLSpecializace(filePath);

                    // Zobrazit úspěšnou zprávu
                    MessageBox.Show("Data úspěšně exportována.", "Úspěch", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                // Zobrazit chybovou zprávu
                MessageBox.Show($"Chyba při exportu dat: {ex.Message}", "Chyba", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void VojaciBtn_Click(object sender, EventArgs e)
        {
            try
            {
                // Vytvořte novou instanci SaveFileDialog
                SaveFileDialog saveFileDialog = new SaveFileDialog();

                // Nastavte vlastnosti dialogu pro uložení souboru
                saveFileDialog.Filter = "XML soubory (*.xml)|*.xml"; // Nastavte filtr pro zobrazení pouze XML souborů
                saveFileDialog.FileName = "dataVojaci.xml"; // Výchozí název souboru
                saveFileDialog.Title = "Exportovat data vojáků"; // Nadpis dialogu

                // Zobrazit dialog pro uložení souboru
                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    string filePath = saveFileDialog.FileName; // Získejte vybranou cestu k souboru

                    // Exportovat data do XML pomocí vybrané cesty k souboru
                    exportController.ExportToXMLVojaci(filePath);

                    // Zobrazit úspěšnou zprávu
                    MessageBox.Show("Data úspěšně exportována.", "Úspěch", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                // Zobrazit chybovou zprávu
                MessageBox.Show($"Chyba při exportu dat: {ex.Message}", "Chyba", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        private void UtvaryBtn_Click(object sender, EventArgs e)
        {
            try
            {
                // Vytvořte novou instanci SaveFileDialog
                SaveFileDialog saveFileDialog = new SaveFileDialog();

                // Nastavte vlastnosti dialogu pro uložení souboru
                saveFileDialog.Filter = "XML soubory (*.xml)|*.xml"; // Nastavte filtr pro zobrazení pouze XML souborů
                saveFileDialog.FileName = "dataUtvary.xml"; // Výchozí název souboru
                saveFileDialog.Title = "Exportovat data útvarů"; // Nadpis dialogu

                // Zobrazit dialog pro uložení souboru
                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    string filePath = saveFileDialog.FileName; // Získejte vybranou cestu k souboru

                    // Exportovat data do XML pomocí vybrané cesty k souboru
                    exportController.ExportToXMLUtvary(filePath);

                    // Zobrazit úspěšnou zprávu
                    MessageBox.Show("Data úspěšně exportována.", "Úspěch", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                // Zobrazit chybovou zprávu
                MessageBox.Show($"Chyba při exportu dat: {ex.Message}", "Chyba", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        private void ZkouskyBtn_Click(object sender, EventArgs e)
        {
            try
            {
                // Vytvořte novou instanci SaveFileDialog
                SaveFileDialog saveFileDialog = new SaveFileDialog();

                // Nastavte vlastnosti dialogu pro uložení souboru
                saveFileDialog.Filter = "XML soubory (*.xml)|*.xml"; // Nastavte filtr pro zobrazení pouze XML souborů
                saveFileDialog.FileName = "dataZkousky.xml"; // Výchozí název souboru
                saveFileDialog.Title = "Exportovat data zkoušek"; // Nadpis dialogu

                // Zobrazit dialog pro uložení souboru
                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    string filePath = saveFileDialog.FileName; // Získejte vybranou cestu k souboru

                    // Exportovat data do XML pomocí vybrané cesty k souboru
                    exportController.ExportToXMLZkousky(filePath);

                    // Zobrazit úspěšnou zprávu
                    MessageBox.Show("Data úspěšně exportována.", "Úspěch", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                // Zobrazit chybovou zprávu
                MessageBox.Show($"Chyba při exportu dat: {ex.Message}", "Chyba", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

    }
}
