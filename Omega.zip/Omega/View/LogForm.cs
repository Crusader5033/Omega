﻿using Omega.Controller;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Omega.View
{
    public partial class LogForm : Form
    {
        private LogController logController = new LogController();
        private ExportCSVController exportCSVController;
        private ExportXMLController exportXMLController;

        public LogForm()
        {
            InitializeComponent();
            LoadLogsIntoDataGridView();
            exportCSVController = new ExportCSVController();
            exportXMLController = new ExportXMLController();


        }
        private void LoadLogsIntoDataGridView()
        {
            var logsDataTable = logController.ListLogs();

            if (logsDataTable != null)
            {
                LogView.DataSource = logsDataTable;
            }
            else
            {
                MessageBox.Show("Chyba při získávání dat z databáze.");
            }
        }
        private void LogView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void ExportXMLBtn_Click(object sender, EventArgs e)
        {
            try
            {
                // Create a new SaveFileDialog instance
                SaveFileDialog saveFileDialog = new SaveFileDialog();

                // Set properties for the file dialog
                saveFileDialog.Filter = "XML Files (*.xml)|*.xml"; // Set filter to show only XML files
                saveFileDialog.FileName = "dataLogs.xml"; // Default file name
                saveFileDialog.Title = "Export Logs Data"; // Dialog title

                // Show the file dialog
                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    string filePath = saveFileDialog.FileName; // Get the selected file path

                    // Export data to XML using the selected file path
                    exportXMLController.ExportToXMLLogs(filePath);

                    // Show a success message
                    MessageBox.Show("Data exported successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                // Show an error message
                MessageBox.Show($"Error exporting data: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ExportCSVBtn_Click(object sender, EventArgs e)
        {
            try
            {
                // Create a new SaveFileDialog instance
                SaveFileDialog saveFileDialog = new SaveFileDialog();

                // Set properties for the file dialog
                saveFileDialog.Filter = "CSV Files (*.csv)|*.csv"; // Set filter to show only CSV files
                saveFileDialog.FileName = "dataLogy.csv"; // Default file name
                saveFileDialog.Title = "Export Logs Data"; // Dialog title

                // Show the file dialog
                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    string filePath = saveFileDialog.FileName; // Get the selected file path

                    // Export data to CSV using the selected file path
                    exportCSVController.ExportToCSVLogs(filePath);

                    // Show a success message
                    MessageBox.Show("Data exported successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                // Show an error message
                MessageBox.Show($"Error exporting data: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
