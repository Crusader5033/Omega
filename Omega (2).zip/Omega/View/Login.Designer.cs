﻿namespace Omega.View
{
    partial class Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.kryptonLabel1 = new ComponentFactory.Krypton.Toolkit.KryptonLabel();
            this.registraceBtn = new ComponentFactory.Krypton.Toolkit.KryptonButton();
            this.prihlasitBtn = new ComponentFactory.Krypton.Toolkit.KryptonButton();
            this.UsernameBox = new ComponentFactory.Krypton.Toolkit.KryptonTextBox();
            this.PasswordBox = new ComponentFactory.Krypton.Toolkit.KryptonTextBox();
            this.kryptonLabel2 = new ComponentFactory.Krypton.Toolkit.KryptonLabel();
            this.kryptonLabel3 = new ComponentFactory.Krypton.Toolkit.KryptonLabel();
            this.kryptonLinkLabel1 = new ComponentFactory.Krypton.Toolkit.KryptonLinkLabel();
            this.SuspendLayout();
            // 
            // kryptonLabel1
            // 
            this.kryptonLabel1.LabelStyle = ComponentFactory.Krypton.Toolkit.LabelStyle.KeyTip;
            this.kryptonLabel1.Location = new System.Drawing.Point(225, 20);
            this.kryptonLabel1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.kryptonLabel1.Name = "kryptonLabel1";
            this.kryptonLabel1.Size = new System.Drawing.Size(57, 14);
            this.kryptonLabel1.TabIndex = 7;
            this.kryptonLabel1.Values.Text = "Přihlášení";
            // 
            // registraceBtn
            // 
            this.registraceBtn.Location = new System.Drawing.Point(200, 196);
            this.registraceBtn.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.registraceBtn.Name = "registraceBtn";
            this.registraceBtn.PaletteMode = ComponentFactory.Krypton.Toolkit.PaletteMode.Office2010Blue;
            this.registraceBtn.Size = new System.Drawing.Size(99, 38);
            this.registraceBtn.TabIndex = 8;
            this.registraceBtn.Values.Text = "Registrace";
            this.registraceBtn.Click += new System.EventHandler(this.registraceBtn_Click);
            // 
            // prihlasitBtn
            // 
            this.prihlasitBtn.Location = new System.Drawing.Point(200, 140);
            this.prihlasitBtn.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.prihlasitBtn.Name = "prihlasitBtn";
            this.prihlasitBtn.PaletteMode = ComponentFactory.Krypton.Toolkit.PaletteMode.Office2010Blue;
            this.prihlasitBtn.Size = new System.Drawing.Size(99, 38);
            this.prihlasitBtn.TabIndex = 9;
            this.prihlasitBtn.Values.Text = "Přihlásit se";
            this.prihlasitBtn.Click += new System.EventHandler(this.prihlasitBtn_Click);
            // 
            // UsernameBox
            // 
            this.UsernameBox.Location = new System.Drawing.Point(177, 75);
            this.UsernameBox.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.UsernameBox.Name = "UsernameBox";
            this.UsernameBox.PaletteMode = ComponentFactory.Krypton.Toolkit.PaletteMode.Office2010Blue;
            this.UsernameBox.Size = new System.Drawing.Size(151, 23);
            this.UsernameBox.TabIndex = 10;
            // 
            // PasswordBox
            // 
            this.PasswordBox.Location = new System.Drawing.Point(177, 109);
            this.PasswordBox.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.PasswordBox.Name = "PasswordBox";
            this.PasswordBox.PaletteMode = ComponentFactory.Krypton.Toolkit.PaletteMode.Office2010Blue;
            this.PasswordBox.PasswordChar = '●';
            this.PasswordBox.Size = new System.Drawing.Size(151, 23);
            this.PasswordBox.TabIndex = 11;
            this.PasswordBox.UseSystemPasswordChar = true;
            // 
            // kryptonLabel2
            // 
            this.kryptonLabel2.Location = new System.Drawing.Point(60, 75);
            this.kryptonLabel2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.kryptonLabel2.Name = "kryptonLabel2";
            this.kryptonLabel2.PaletteMode = ComponentFactory.Krypton.Toolkit.PaletteMode.Office2010Blue;
            this.kryptonLabel2.Size = new System.Drawing.Size(109, 20);
            this.kryptonLabel2.TabIndex = 12;
            this.kryptonLabel2.Values.Text = "Uživatelské jméno";
            // 
            // kryptonLabel3
            // 
            this.kryptonLabel3.Location = new System.Drawing.Point(77, 109);
            this.kryptonLabel3.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.kryptonLabel3.Name = "kryptonLabel3";
            this.kryptonLabel3.PaletteMode = ComponentFactory.Krypton.Toolkit.PaletteMode.Office2010Blue;
            this.kryptonLabel3.Size = new System.Drawing.Size(41, 20);
            this.kryptonLabel3.TabIndex = 13;
            this.kryptonLabel3.Values.Text = "Heslo";
            // 
            // kryptonLinkLabel1
            // 
            this.kryptonLinkLabel1.Location = new System.Drawing.Point(189, 260);
            this.kryptonLinkLabel1.Name = "kryptonLinkLabel1";
            this.kryptonLinkLabel1.PaletteMode = ComponentFactory.Krypton.Toolkit.PaletteMode.Office2010Blue;
            this.kryptonLinkLabel1.Size = new System.Drawing.Size(124, 20);
            this.kryptonLinkLabel1.TabIndex = 14;
            this.kryptonLinkLabel1.Values.Text = "Kontaktujte podporu";
            this.kryptonLinkLabel1.LinkClicked += new System.EventHandler(this.kryptonLinkLabel1_LinkClicked);
            // 
            // Login
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(495, 292);
            this.Controls.Add(this.kryptonLinkLabel1);
            this.Controls.Add(this.kryptonLabel3);
            this.Controls.Add(this.kryptonLabel2);
            this.Controls.Add(this.PasswordBox);
            this.Controls.Add(this.UsernameBox);
            this.Controls.Add(this.prihlasitBtn);
            this.Controls.Add(this.registraceBtn);
            this.Controls.Add(this.kryptonLabel1);
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Login";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Přihlášení";
            this.Load += new System.EventHandler(this.Login_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private ComponentFactory.Krypton.Toolkit.KryptonLabel kryptonLabel1;
        private ComponentFactory.Krypton.Toolkit.KryptonButton registraceBtn;
        private ComponentFactory.Krypton.Toolkit.KryptonButton prihlasitBtn;
        private ComponentFactory.Krypton.Toolkit.KryptonTextBox UsernameBox;
        private ComponentFactory.Krypton.Toolkit.KryptonTextBox PasswordBox;
        private ComponentFactory.Krypton.Toolkit.KryptonLabel kryptonLabel2;
        private ComponentFactory.Krypton.Toolkit.KryptonLabel kryptonLabel3;
        private ComponentFactory.Krypton.Toolkit.KryptonLinkLabel kryptonLinkLabel1;
    }
}