﻿namespace Omega.View
{
    partial class LogForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.LogView = new System.Windows.Forms.DataGridView();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.ExportCSVBtn = new System.Windows.Forms.Button();
            this.ExportXMLBtn = new System.Windows.Forms.Button();
            this.kryptonLabel1 = new ComponentFactory.Krypton.Toolkit.KryptonLabel();
            ((System.ComponentModel.ISupportInitialize)(this.LogView)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.SuspendLayout();
            // 
            // LogView
            // 
            this.LogView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.LogView.Location = new System.Drawing.Point(3, 0);
            this.LogView.Name = "LogView";
            this.LogView.RowTemplate.Height = 28;
            this.LogView.Size = new System.Drawing.Size(977, 237);
            this.LogView.TabIndex = 0;
            this.LogView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.LogView_CellContentClick);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(12, 1);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(988, 437);
            this.tabControl1.TabIndex = 1;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.kryptonLabel1);
            this.tabPage1.Controls.Add(this.LogView);
            this.tabPage1.Location = new System.Drawing.Point(4, 29);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(980, 404);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Logy";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.ExportCSVBtn);
            this.tabPage2.Controls.Add(this.ExportXMLBtn);
            this.tabPage2.Location = new System.Drawing.Point(4, 29);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(980, 404);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Export";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // ExportCSVBtn
            // 
            this.ExportCSVBtn.Location = new System.Drawing.Point(729, 48);
            this.ExportCSVBtn.Name = "ExportCSVBtn";
            this.ExportCSVBtn.Size = new System.Drawing.Size(174, 72);
            this.ExportCSVBtn.TabIndex = 3;
            this.ExportCSVBtn.Text = "Export do CSV";
            this.ExportCSVBtn.UseVisualStyleBackColor = true;
            this.ExportCSVBtn.Click += new System.EventHandler(this.ExportCSVBtn_Click);
            // 
            // ExportXMLBtn
            // 
            this.ExportXMLBtn.Location = new System.Drawing.Point(26, 48);
            this.ExportXMLBtn.Name = "ExportXMLBtn";
            this.ExportXMLBtn.Size = new System.Drawing.Size(174, 72);
            this.ExportXMLBtn.TabIndex = 2;
            this.ExportXMLBtn.Text = "Export do XML";
            this.ExportXMLBtn.UseVisualStyleBackColor = true;
            this.ExportXMLBtn.Click += new System.EventHandler(this.ExportXMLBtn_Click);
            // 
            // kryptonLabel1
            // 
            this.kryptonLabel1.Location = new System.Drawing.Point(81, 290);
            this.kryptonLabel1.Name = "kryptonLabel1";
            this.kryptonLabel1.PaletteMode = ComponentFactory.Krypton.Toolkit.PaletteMode.Office2010Blue;
            this.kryptonLabel1.Size = new System.Drawing.Size(462, 20);
            this.kryptonLabel1.TabIndex = 1;
            this.kryptonLabel1.Values.Text = "Zde je možnost procházet záznamy přihlášení,registrace a nepodařených přihlášení";
            // 
            // LogForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1003, 450);
            this.Controls.Add(this.tabControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "LogForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Záznamy";
            ((System.ComponentModel.ISupportInitialize)(this.LogView)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView LogView;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button ExportCSVBtn;
        private System.Windows.Forms.Button ExportXMLBtn;
        private ComponentFactory.Krypton.Toolkit.KryptonLabel kryptonLabel1;
    }
}