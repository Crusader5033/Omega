﻿using Omega.Model;
using System;
using System.Data;

namespace Omega.Controller
{
    /// <summary>
    /// Represents a controller class for handling operations related to logs.
    /// </summary>
    public class LogController
    {
        private Log l;

        /// <summary>
        /// Initializes a new instance of the <see cref="LogController"/> class.
        /// </summary>
        public LogController()
        {
            // Instantiates a Log object to interact with log-related database operations.
            this.l = new Log();
        }
        public DataTable ListLogs()
        {
            // Calls the GetSluzby method of the associated Sluzba object to retrieve military service information.
            return this.l.GetLogs();
        }
        public void DeleteLog(int id)
        {
            // Calls the AddLog method of the associated Log object to add a new log entry to the database.
            this.l.DeleteLogWithID(id);
        }
        /// <summary>
        /// Adds a new log entry to the database.
        /// </summary>
        /// <param name="logDate">The date of the log entry.</param>
        /// <param name="logType">The type of the log entry.</param>
        /// <param name="userId">The ID of the user associated with the log entry.</param>
        public void AddLog(DateTime logDate, string logType, int userId)
        {
            // Calls the AddLog method of the associated Log object to add a new log entry to the database.
            this.l.AddLog(logDate, logType, userId);
        }
    }
}
