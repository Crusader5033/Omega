﻿using Omega.Controller;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Omega.View
{
    public partial class ExportCSVForm : Form
    {
        private ExportCSVController exportController;
        public ExportCSVForm()
        {
            InitializeComponent();
            exportController = new ExportCSVController();
        }


        private void SluzbyExportBtn_Click(object sender, EventArgs e)
        {
            try
            {
                // Vytvořte novou instanci SaveFileDialog
                SaveFileDialog saveFileDialog = new SaveFileDialog();

                // Nastavte vlastnosti dialogu pro uložení souboru
                saveFileDialog.Filter = "CSV soubory (*.csv)|*.csv"; // Nastavte filtr pro zobrazení pouze CSV souborů
                saveFileDialog.FileName = "dataSluzby.csv"; // Výchozí název souboru
                saveFileDialog.Title = "Exportovat data služeb"; // Nadpis dialogu

                // Zobrazit dialog pro uložení souboru
                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    string filePath = saveFileDialog.FileName; // Získejte vybranou cestu k souboru

                    // Exportovat data do CSV pomocí vybrané cesty k souboru
                    exportController.ExportToCSVSluzby(filePath);

                    // Zobrazit úspěšnou zprávu
                    MessageBox.Show("Data úspěšně exportována.", "Úspěch", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                // Zobrazit chybovou zprávu
                MessageBox.Show($"Chyba při exportu dat: {ex.Message}", "Chyba", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }



        private void SpecializaceExportBtn_Click(object sender, EventArgs e)
        {
            try
            {
                // Vytvořte novou instanci SaveFileDialog
                SaveFileDialog saveFileDialog = new SaveFileDialog();

                // Nastavte vlastnosti dialogu pro uložení souboru
                saveFileDialog.Filter = "CSV soubory (*.csv)|*.csv"; // Nastavte filtr pro zobrazení pouze CSV souborů
                saveFileDialog.FileName = "dataSpecializace.csv"; // Výchozí název souboru
                saveFileDialog.Title = "Exportovat data specializací"; // Nadpis dialogu

                // Zobrazit dialog pro uložení souboru
                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    string filePath = saveFileDialog.FileName; // Získejte vybranou cestu k souboru

                    // Exportovat data do CSV pomocí vybrané cesty k souboru
                    exportController.ExportToCSVSpecializace(filePath);

                    // Zobrazit úspěšnou zprávu
                    MessageBox.Show("Data úspěšně exportována.", "Úspěch", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                // Zobrazit chybovou zprávu
                MessageBox.Show($"Chyba při exportu dat: {ex.Message}", "Chyba", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        private void ZkouskyBtn_Click(object sender, EventArgs e)
        {
            try
            {
                // Vytvořte novou instanci SaveFileDialog
                SaveFileDialog saveFileDialog = new SaveFileDialog();

                // Nastavte vlastnosti dialogu pro uložení souboru
                saveFileDialog.Filter = "CSV soubory (*.csv)|*.csv"; // Nastavte filtr pro zobrazení pouze CSV souborů
                saveFileDialog.FileName = "dataZkousky.csv"; // Výchozí název souboru
                saveFileDialog.Title = "Exportovat data zkoušek"; // Nadpis dialogu

                // Zobrazit dialog pro uložení souboru
                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    string filePath = saveFileDialog.FileName; // Získejte vybranou cestu k souboru

                    // Exportovat data do CSV pomocí vybrané cesty k souboru
                    exportController.ExportToCSVZkousky(filePath);

                    // Zobrazit úspěšnou zprávu
                    MessageBox.Show("Data úspěšně exportována.", "Úspěch", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                // Zobrazit chybovou zprávu
                MessageBox.Show($"Chyba při exportu dat: {ex.Message}", "Chyba", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void UtvaryBtn_Click(object sender, EventArgs e)
        {
            try
            {
                // Vytvořte novou instanci SaveFileDialog
                SaveFileDialog saveFileDialog = new SaveFileDialog();

                // Nastavte vlastnosti dialogu pro uložení souboru
                saveFileDialog.Filter = "CSV soubory (*.csv)|*.csv"; // Nastavte filtr pro zobrazení pouze CSV souborů
                saveFileDialog.FileName = "dataUtvary.csv"; // Výchozí název souboru
                saveFileDialog.Title = "Exportovat data útvarů"; // Nadpis dialogu

                // Zobrazit dialog pro uložení souboru
                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    string filePath = saveFileDialog.FileName; // Získejte vybranou cestu k souboru

                    // Exportovat data do CSV pomocí vybrané cesty k souboru
                    exportController.ExportToCSVUtvar(filePath);

                    // Zobrazit úspěšnou zprávu
                    MessageBox.Show("Data úspěšně exportována.", "Úspěch", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                // Zobrazit chybovou zprávu
                MessageBox.Show($"Chyba při exportu dat: {ex.Message}", "Chyba", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void RoleBtn_Click(object sender, EventArgs e)
        {
            try
            {
                // Vytvořte novou instanci SaveFileDialog
                SaveFileDialog saveFileDialog = new SaveFileDialog();

                // Nastavte vlastnosti dialogu pro uložení souboru
                saveFileDialog.Filter = "CSV soubory (*.csv)|*.csv"; // Nastavte filtr pro zobrazení pouze CSV souborů
                saveFileDialog.FileName = "dataRole.csv"; // Výchozí název souboru
                saveFileDialog.Title = "Exportovat data rolí"; // Nadpis dialogu

                // Zobrazit dialog pro uložení souboru
                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    string filePath = saveFileDialog.FileName; // Získejte vybranou cestu k souboru

                    // Exportovat data do CSV pomocí vybrané cesty k souboru
                    exportController.ExportToCSVRole(filePath);

                    // Zobrazit úspěšnou zprávu
                    MessageBox.Show("Data úspěšně exportována.", "Úspěch", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                // Zobrazit chybovou zprávu
                MessageBox.Show($"Chyba při exportu dat: {ex.Message}", "Chyba", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void VojaciBtn_Click(object sender, EventArgs e)
        {
            try
            {
                // Vytvořte novou instanci SaveFileDialog
                SaveFileDialog saveFileDialog = new SaveFileDialog();

                // Nastavte vlastnosti dialogu pro uložení souboru
                saveFileDialog.Filter = "CSV soubory (*.csv)|*.csv"; // Nastavte filtr pro zobrazení pouze CSV souborů
                saveFileDialog.FileName = "dataVojaci.csv"; // Výchozí název souboru
                saveFileDialog.Title = "Exportovat data vojáků"; // Nadpis dialogu

                // Zobrazit dialog pro uložení souboru
                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    string filePath = saveFileDialog.FileName; // Získejte vybranou cestu k souboru

                    // Exportovat data do CSV pomocí vybrané cesty k souboru
                    exportController.ExportToCSVojaci(filePath);

                    // Zobrazit úspěšnou zprávu
                    MessageBox.Show("Data úspěšně exportována.", "Úspěch", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                // Zobrazit chybovou zprávu
                MessageBox.Show($"Chyba při exportu dat: {ex.Message}", "Chyba", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

    }
}
