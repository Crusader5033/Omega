﻿namespace Omega.View
{
    partial class UpdateForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.label3 = new System.Windows.Forms.Label();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.VojakView = new System.Windows.Forms.DataGridView();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.SurnameBox = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.NameBox = new System.Windows.Forms.TextBox();
            this.VojakBtn = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.SluzbaBtn = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.NazevBox = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.ZamereniBox = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.utvarView = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.newPlaceBox = new System.Windows.Forms.TextBox();
            this.utvarBtn = new System.Windows.Forms.Button();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.RoleBtn = new System.Windows.Forms.Button();
            this.RoleBox = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.RoleView = new System.Windows.Forms.DataGridView();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.VojakView)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.utvarView)).BeginInit();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.RoleView)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(796, 447);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.checkBox2);
            this.tabPage1.Controls.Add(this.VojakView);
            this.tabPage1.Controls.Add(this.checkBox1);
            this.tabPage1.Controls.Add(this.SurnameBox);
            this.tabPage1.Controls.Add(this.label6);
            this.tabPage1.Controls.Add(this.NameBox);
            this.tabPage1.Controls.Add(this.VojakBtn);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.SluzbaBtn);
            this.tabPage1.Location = new System.Drawing.Point(4, 29);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(788, 414);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Voják";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(433, 256);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(140, 20);
            this.label3.TabIndex = 19;
            this.label3.Text = "Zůčastnil se mise?";
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Location = new System.Drawing.Point(521, 308);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(48, 24);
            this.checkBox2.TabIndex = 18;
            this.checkBox2.Text = "Ne";
            this.checkBox2.UseVisualStyleBackColor = true;
            this.checkBox2.CheckedChanged += new System.EventHandler(this.checkBox2_CheckedChanged);
            // 
            // VojakView
            // 
            this.VojakView.AllowUserToAddRows = false;
            this.VojakView.AllowUserToDeleteRows = false;
            this.VojakView.AllowUserToOrderColumns = true;
            this.VojakView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.VojakView.Location = new System.Drawing.Point(0, 0);
            this.VojakView.Name = "VojakView";
            this.VojakView.ReadOnly = true;
            this.VojakView.RowTemplate.Height = 28;
            this.VojakView.Size = new System.Drawing.Size(788, 210);
            this.VojakView.TabIndex = 17;
            this.VojakView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.VojakView_CellContentClick);
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(437, 308);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(57, 24);
            this.checkBox1.TabIndex = 16;
            this.checkBox1.Text = "Ano";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // SurnameBox
            // 
            this.SurnameBox.Location = new System.Drawing.Point(228, 308);
            this.SurnameBox.Name = "SurnameBox";
            this.SurnameBox.Size = new System.Drawing.Size(169, 26);
            this.SurnameBox.TabIndex = 15;
            this.SurnameBox.TextChanged += new System.EventHandler(this.SurnameBox_TextChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(224, 265);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(64, 20);
            this.label6.TabIndex = 14;
            this.label6.Text = "Příjmení";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // NameBox
            // 
            this.NameBox.Location = new System.Drawing.Point(8, 308);
            this.NameBox.Name = "NameBox";
            this.NameBox.Size = new System.Drawing.Size(169, 26);
            this.NameBox.TabIndex = 13;
            this.NameBox.TextChanged += new System.EventHandler(this.NameBox_TextChanged);
            // 
            // VojakBtn
            // 
            this.VojakBtn.Location = new System.Drawing.Point(613, 286);
            this.VojakBtn.Name = "VojakBtn";
            this.VojakBtn.Size = new System.Drawing.Size(169, 71);
            this.VojakBtn.TabIndex = 12;
            this.VojakBtn.Text = "Upravit";
            this.VojakBtn.UseVisualStyleBackColor = true;
            this.VojakBtn.Click += new System.EventHandler(this.VojakBtn_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(4, 265);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(57, 20);
            this.label2.TabIndex = 7;
            this.label2.Text = "Jméno";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // SluzbaBtn
            // 
            this.SluzbaBtn.Location = new System.Drawing.Point(0, 0);
            this.SluzbaBtn.Name = "SluzbaBtn";
            this.SluzbaBtn.Size = new System.Drawing.Size(75, 23);
            this.SluzbaBtn.TabIndex = 11;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.NazevBox);
            this.tabPage2.Controls.Add(this.label5);
            this.tabPage2.Controls.Add(this.ZamereniBox);
            this.tabPage2.Controls.Add(this.label4);
            this.tabPage2.Controls.Add(this.utvarView);
            this.tabPage2.Controls.Add(this.label1);
            this.tabPage2.Controls.Add(this.newPlaceBox);
            this.tabPage2.Controls.Add(this.utvarBtn);
            this.tabPage2.Location = new System.Drawing.Point(4, 29);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(788, 414);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Utvar";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // NazevBox
            // 
            this.NazevBox.Location = new System.Drawing.Point(426, 349);
            this.NazevBox.Name = "NazevBox";
            this.NazevBox.Size = new System.Drawing.Size(169, 26);
            this.NazevBox.TabIndex = 8;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(456, 289);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(93, 20);
            this.label5.TabIndex = 7;
            this.label5.Text = "Nový název:";
            // 
            // ZamereniBox
            // 
            this.ZamereniBox.Location = new System.Drawing.Point(226, 349);
            this.ZamereniBox.Name = "ZamereniBox";
            this.ZamereniBox.Size = new System.Drawing.Size(169, 26);
            this.ZamereniBox.TabIndex = 6;
            this.ZamereniBox.TextChanged += new System.EventHandler(this.ZamereniBox_TextChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(256, 289);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(118, 20);
            this.label4.TabIndex = 5;
            this.label4.Text = "Nové zaměření:";
            // 
            // utvarView
            // 
            this.utvarView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.utvarView.Location = new System.Drawing.Point(0, 0);
            this.utvarView.Name = "utvarView";
            this.utvarView.RowTemplate.Height = 28;
            this.utvarView.Size = new System.Drawing.Size(788, 210);
            this.utvarView.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(40, 289);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(122, 20);
            this.label1.TabIndex = 3;
            this.label1.Text = "Nové působiště:";
            // 
            // newPlaceBox
            // 
            this.newPlaceBox.Location = new System.Drawing.Point(22, 349);
            this.newPlaceBox.Name = "newPlaceBox";
            this.newPlaceBox.Size = new System.Drawing.Size(169, 26);
            this.newPlaceBox.TabIndex = 2;
            // 
            // utvarBtn
            // 
            this.utvarBtn.Location = new System.Drawing.Point(613, 327);
            this.utvarBtn.Name = "utvarBtn";
            this.utvarBtn.Size = new System.Drawing.Size(169, 71);
            this.utvarBtn.TabIndex = 1;
            this.utvarBtn.Text = "Upravit";
            this.utvarBtn.UseVisualStyleBackColor = true;
            this.utvarBtn.Click += new System.EventHandler(this.utvarBtn_Click);
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.RoleBtn);
            this.tabPage3.Controls.Add(this.RoleBox);
            this.tabPage3.Controls.Add(this.label7);
            this.tabPage3.Controls.Add(this.RoleView);
            this.tabPage3.Location = new System.Drawing.Point(4, 29);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(788, 414);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Role";
            this.tabPage3.UseVisualStyleBackColor = true;
            this.tabPage3.Click += new System.EventHandler(this.tabPage3_Click);
            // 
            // RoleBtn
            // 
            this.RoleBtn.Location = new System.Drawing.Point(600, 275);
            this.RoleBtn.Name = "RoleBtn";
            this.RoleBtn.Size = new System.Drawing.Size(169, 71);
            this.RoleBtn.TabIndex = 22;
            this.RoleBtn.Text = "Upravit";
            this.RoleBtn.UseVisualStyleBackColor = true;
            this.RoleBtn.Click += new System.EventHandler(this.RoleBtn_Click);
            // 
            // RoleBox
            // 
            this.RoleBox.Location = new System.Drawing.Point(40, 297);
            this.RoleBox.Name = "RoleBox";
            this.RoleBox.Size = new System.Drawing.Size(169, 26);
            this.RoleBox.TabIndex = 21;
            this.RoleBox.TextChanged += new System.EventHandler(this.RoleBox_TextChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(36, 253);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(53, 20);
            this.label7.TabIndex = 20;
            this.label7.Text = "Název";
            // 
            // RoleView
            // 
            this.RoleView.AllowUserToAddRows = false;
            this.RoleView.AllowUserToDeleteRows = false;
            this.RoleView.AllowUserToOrderColumns = true;
            this.RoleView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.RoleView.Location = new System.Drawing.Point(0, 0);
            this.RoleView.Name = "RoleView";
            this.RoleView.ReadOnly = true;
            this.RoleView.RowTemplate.Height = 28;
            this.RoleView.Size = new System.Drawing.Size(788, 210);
            this.RoleView.TabIndex = 18;
            this.RoleView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.RoleView_CellContentClick);
            // 
            // UpdateForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tabControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "UpdateForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Úprava dat";
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.VojakView)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.utvarView)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.RoleView)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button SluzbaBtn;
        private System.Windows.Forms.Button utvarBtn;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox newPlaceBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridView utvarView;
        private System.Windows.Forms.TextBox ZamereniBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox NazevBox;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button VojakBtn;
        private System.Windows.Forms.TextBox SurnameBox;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox NameBox;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.DataGridView VojakView;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.DataGridView RoleView;
        private System.Windows.Forms.TextBox RoleBox;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button RoleBtn;
    }
}