﻿using Omega.Controller;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Omega.View
{
    /// <summary>
    /// Form for exporting data to XML format for different entities.
    /// </summary>
    public partial class ExportXMLForm : Form
    {
        private ExportXMLController exportController;

        /// <summary>
        /// Constructor for the ExportXMLForm class.
        /// </summary>
        public ExportXMLForm()
        {
            InitializeComponent();
            exportController = new ExportXMLController();
        }

        // Event handler for exporting role data to XML
        private void RoleBtn_Click(object sender, EventArgs e)
        {
            try
            {
                // Create a new instance of SaveFileDialog
                SaveFileDialog saveFileDialog = new SaveFileDialog();

                // Set properties for the file dialog
                saveFileDialog.Filter = "XML files (*.xml)|*.xml"; // Set filter to show only XML files
                saveFileDialog.FileName = "dataRole.xml"; // Default file name
                saveFileDialog.Title = "Export Role Data"; // Dialog title

                // Show the file dialog
                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    string filePath = saveFileDialog.FileName; // Get the selected file path

                    // Export data to XML using the selected file path
                    exportController.ExportToXMLRole(filePath);

                    // Show a success message
                    MessageBox.Show("Data successfully exported.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                // Show an error message
                MessageBox.Show($"Error exporting data: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Event handler for exporting service data to XML
        private void ExportSluzbyBtn_Click(object sender, EventArgs e)
        {
            try
            {
                // Create a new instance of SaveFileDialog
                SaveFileDialog saveFileDialog = new SaveFileDialog();

                // Set properties for the file dialog
                saveFileDialog.Filter = "XML files (*.xml)|*.xml"; // Set filter to show only XML files
                saveFileDialog.FileName = "dataSluzby.xml"; // Default file name
                saveFileDialog.Title = "Export Service Data"; // Dialog title

                // Show the file dialog
                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    string filePath = saveFileDialog.FileName; // Get the selected file path

                    // Export data to XML using the selected file path
                    exportController.ExportToXMLSluzby(filePath);

                    // Show a success message
                    MessageBox.Show("Data successfully exported.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                // Show an error message
                MessageBox.Show($"Error exporting data: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Event handler for exporting specialization data to XML
        private void SpecializaceBtn_Click(object sender, EventArgs e)
        {
            try
            {
                // Create a new instance of SaveFileDialog
                SaveFileDialog saveFileDialog = new SaveFileDialog();

                // Set properties for the file dialog
                saveFileDialog.Filter = "XML files (*.xml)|*.xml"; // Set filter to show only XML files
                saveFileDialog.FileName = "dataSpecializace.xml"; // Default file name
                saveFileDialog.Title = "Export Specialization Data"; // Dialog title

                // Show the file dialog
                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    string filePath = saveFileDialog.FileName; // Get the selected file path

                    // Export data to XML using the selected file path
                    exportController.ExportToXMLSpecializace(filePath);

                    // Show a success message
                    MessageBox.Show("Data successfully exported.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                // Show an error message
                MessageBox.Show($"Error exporting data: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Event handler for exporting soldier data to XML
        private void VojaciBtn_Click(object sender, EventArgs e)
        {
            try
            {
                // Create a new instance of SaveFileDialog
                SaveFileDialog saveFileDialog = new SaveFileDialog();

                // Set properties for the file dialog
                saveFileDialog.Filter = "XML files (*.xml)|*.xml"; // Set filter to show only XML files
                saveFileDialog.FileName = "dataVojaci.xml"; // Default file name
                saveFileDialog.Title = "Export Soldier Data"; // Dialog title

                // Show the file dialog
                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    string filePath = saveFileDialog.FileName; // Get the selected file path

                    // Export data to XML using the selected file path
                    exportController.ExportToXMLVojaci(filePath);

                    // Show a success message
                    MessageBox.Show("Data successfully exported.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                // Show an error message
                MessageBox.Show($"Error exporting data: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Event handler for exporting unit data to XML
        private void UtvaryBtn_Click(object sender, EventArgs e)
        {
            try
            {
                // Create a new instance of SaveFileDialog
                SaveFileDialog saveFileDialog = new SaveFileDialog();

                // Set properties for the file dialog
                saveFileDialog.Filter = "XML files (*.xml)|*.xml"; // Set filter to show only XML files
                saveFileDialog.FileName = "dataUtvary.xml"; // Default file name
                saveFileDialog.Title = "Export Unit Data"; // Dialog title

                // Show the file dialog
                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    string filePath = saveFileDialog.FileName; // Get the selected file path

                    // Export data to XML using the selected file path
                    exportController.ExportToXMLUtvary(filePath);

                    // Show a success message
                    MessageBox.Show("Data successfully exported.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                // Show an error message
                MessageBox.Show($"Error exporting data: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Event handler for exporting examination data to XML
        private void ZkouskyBtn_Click(object sender, EventArgs e)
        {
            try
            {
                // Create a new instance of SaveFileDialog
                SaveFileDialog saveFileDialog = new SaveFileDialog();

                // Set properties for the file dialog
                saveFileDialog.Filter = "XML files (*.xml)|*.xml"; // Set filter to show only XML files
                saveFileDialog.FileName = "dataZkousky.xml"; // Default file name
                saveFileDialog.Title = "Export Examination Data"; // Dialog title

                // Show the file dialog
                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    string filePath = saveFileDialog.FileName; // Get the selected file path

                    // Export data to XML using the selected file path
                    exportController.ExportToXMLZkousky(filePath);

                    // Show a success message
                    MessageBox.Show("Data successfully exported.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                // Show an error message
                MessageBox.Show($"Error exporting data: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
