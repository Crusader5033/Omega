﻿namespace Omega
{
    partial class Form1
    {
        /// <summary>
        /// Vyžaduje se proměnná návrháře.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Uvolněte všechny používané prostředky.
        /// </summary>
        /// <param name="disposing">hodnota true, když by se měl spravovaný prostředek odstranit; jinak false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kód generovaný Návrhářem Windows Form

        /// <summary>
        /// Metoda vyžadovaná pro podporu Návrháře - neupravovat
        /// obsah této metody v editoru kódu.
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SelectBtn = new ComponentFactory.Krypton.Toolkit.KryptonButton();
            this.InsertBtn = new ComponentFactory.Krypton.Toolkit.KryptonButton();
            this.DeleteBtn = new ComponentFactory.Krypton.Toolkit.KryptonButton();
            this.UpdateBtn = new ComponentFactory.Krypton.Toolkit.KryptonButton();
            this.XMLExportBtn = new ComponentFactory.Krypton.Toolkit.KryptonButton();
            this.ExportCVSBtn = new ComponentFactory.Krypton.Toolkit.KryptonButton();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Omega.Properties.Resources.Logo_of_the_Czech_Armed_Forces_svg;
            this.pictureBox1.Location = new System.Drawing.Point(440, 100);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(250, 250);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox1.TabIndex = 3;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.Location = new System.Drawing.Point(362, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(400, 31);
            this.label1.TabIndex = 4;
            this.label1.Text = "Správa služby vojáka z povolání";
            // 
            // SelectBtn
            // 
            this.SelectBtn.Location = new System.Drawing.Point(18, 18);
            this.SelectBtn.Name = "SelectBtn";
            this.SelectBtn.PaletteMode = ComponentFactory.Krypton.Toolkit.PaletteMode.Office2010Blue;
            this.SelectBtn.Size = new System.Drawing.Size(201, 67);
            this.SelectBtn.TabIndex = 8;
            this.SelectBtn.Values.Text = "Výpis";
            this.SelectBtn.Click += new System.EventHandler(this.SelectBtn_Click);
            // 
            // InsertBtn
            // 
            this.InsertBtn.Location = new System.Drawing.Point(18, 119);
            this.InsertBtn.Name = "InsertBtn";
            this.InsertBtn.PaletteMode = ComponentFactory.Krypton.Toolkit.PaletteMode.Office2010Blue;
            this.InsertBtn.Size = new System.Drawing.Size(201, 67);
            this.InsertBtn.TabIndex = 9;
            this.InsertBtn.Values.Text = "Vložit";
            this.InsertBtn.Click += new System.EventHandler(this.InsertBtn_Click);
            // 
            // DeleteBtn
            // 
            this.DeleteBtn.Location = new System.Drawing.Point(18, 232);
            this.DeleteBtn.Name = "DeleteBtn";
            this.DeleteBtn.PaletteMode = ComponentFactory.Krypton.Toolkit.PaletteMode.Office2010Blue;
            this.DeleteBtn.Size = new System.Drawing.Size(201, 67);
            this.DeleteBtn.TabIndex = 10;
            this.DeleteBtn.Values.Text = "Smazat";
            this.DeleteBtn.Click += new System.EventHandler(this.DeleteBtn_Click);
            // 
            // UpdateBtn
            // 
            this.UpdateBtn.Location = new System.Drawing.Point(18, 351);
            this.UpdateBtn.Name = "UpdateBtn";
            this.UpdateBtn.PaletteMode = ComponentFactory.Krypton.Toolkit.PaletteMode.Office2010Blue;
            this.UpdateBtn.Size = new System.Drawing.Size(201, 67);
            this.UpdateBtn.TabIndex = 11;
            this.UpdateBtn.Values.Text = "Upravit";
            this.UpdateBtn.Click += new System.EventHandler(this.UpdateBtn_Click);
            // 
            // XMLExportBtn
            // 
            this.XMLExportBtn.Location = new System.Drawing.Point(18, 556);
            this.XMLExportBtn.Name = "XMLExportBtn";
            this.XMLExportBtn.PaletteMode = ComponentFactory.Krypton.Toolkit.PaletteMode.Office2010Blue;
            this.XMLExportBtn.Size = new System.Drawing.Size(201, 67);
            this.XMLExportBtn.TabIndex = 13;
            this.XMLExportBtn.Values.Text = "Export do XML";
            this.XMLExportBtn.Click += new System.EventHandler(this.XMLExportBtn_Click);
            // 
            // ExportCVSBtn
            // 
            this.ExportCVSBtn.Location = new System.Drawing.Point(18, 457);
            this.ExportCVSBtn.Name = "ExportCVSBtn";
            this.ExportCVSBtn.PaletteMode = ComponentFactory.Krypton.Toolkit.PaletteMode.Office2010Blue;
            this.ExportCVSBtn.Size = new System.Drawing.Size(201, 67);
            this.ExportCVSBtn.TabIndex = 12;
            this.ExportCVSBtn.Values.Text = "Export do CSV";
            this.ExportCVSBtn.Click += new System.EventHandler(this.ExportCVSBtn_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1204, 635);
            this.Controls.Add(this.XMLExportBtn);
            this.Controls.Add(this.ExportCVSBtn);
            this.Controls.Add(this.UpdateBtn);
            this.Controls.Add(this.DeleteBtn);
            this.Controls.Add(this.InsertBtn);
            this.Controls.Add(this.SelectBtn);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "SSAČR";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private ComponentFactory.Krypton.Toolkit.KryptonButton SelectBtn;
        private ComponentFactory.Krypton.Toolkit.KryptonButton InsertBtn;
        private ComponentFactory.Krypton.Toolkit.KryptonButton DeleteBtn;
        private ComponentFactory.Krypton.Toolkit.KryptonButton UpdateBtn;
        private ComponentFactory.Krypton.Toolkit.KryptonButton XMLExportBtn;
        private ComponentFactory.Krypton.Toolkit.KryptonButton ExportCVSBtn;
    }
}

