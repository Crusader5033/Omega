﻿using Omega.View;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Omega
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            this.FormClosed += Form1_FormClosed;
        }

      
       
  
        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit(); // Close the application when Form1 is closed
        }

      

      

        private void SelectBtn_Click(object sender, EventArgs e)
        {
            SelectForm selectForm = new SelectForm();
            selectForm.Show();
        }

        private void InsertBtn_Click(object sender, EventArgs e)
        {

            InsertForm insertForm = new InsertForm();
            insertForm.Show();
        }

        private void DeleteBtn_Click(object sender, EventArgs e)
        {
            DeleteForm deleteForm = new DeleteForm();
            deleteForm.Show();
        }

        private void UpdateBtn_Click(object sender, EventArgs e)
        {
            UpdateForm updateForm = new UpdateForm();
            updateForm.Show();
        }

        private void ExportCVSBtn_Click(object sender, EventArgs e)
        {
            ExportCSVForm exportform = new ExportCSVForm();
            exportform.Show();
        }

        private void XMLExportBtn_Click(object sender, EventArgs e)
        {
            ExportXMLForm exportform = new ExportXMLForm();
            exportform.Show();
        }

        private void kryptonGroupBox1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
