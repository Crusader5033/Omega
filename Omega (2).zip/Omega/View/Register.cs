﻿using Omega.Controller;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Omega.View
{
    /// <summary>
    /// Represents a form for user registration in the Omega application.
    /// </summary>
    public partial class Register : Form
    {
        private UserController userController; // Instance of UserController for user management
        private LogController logController; // Instance of LogController for logging

        /// <summary>
        /// Initializes a new instance of the <see cref="Register"/> class.
        /// </summary>
        public Register()
        {
            InitializeComponent();

            userController = new UserController();
            logController = new LogController();
        }

        private void NameBox_TextChanged(object sender, EventArgs e) { }

        private void SurnameBox_TextChanged(object sender, EventArgs e) { }

        private void UsernameBox_TextChanged(object sender, EventArgs e) { }

        private void PasswordBox_TextChanged(object sender, EventArgs e) { }

        private void EmailBox_TextChanged(object sender, EventArgs e) { }

        /// <summary>
        /// Event handler for the registration button click event.
        /// </summary>
        private void RegisterBtn_Click_1(object sender, EventArgs e)
        {
            try
            {
                // Get user information from the form
                string jmeno = NameBox.Text;
                string prijmeni = SurnameBox.Text;
                string uzivatelskeJmeno = UsernameBox.Text;
                string heslo = PasswordBox.Text;
                string email = EmailBox.Text; 

                // Check if all fields are filled
                if (string.IsNullOrEmpty(jmeno) || string.IsNullOrEmpty(prijmeni) || string.IsNullOrEmpty(uzivatelskeJmeno) || string.IsNullOrEmpty(heslo) || string.IsNullOrEmpty(email))
                {
                    MessageBox.Show("Prosím, vyplňte všechna pole.", "Oznámení", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }

                // Add the user to the database and get the ID of the newly inserted user
                int userId = userController.AddUser(uzivatelskeJmeno, heslo, jmeno, prijmeni, email);

                // Log user registration
                DateTime logDate = DateTime.Now;
                string logType = "Registrace";
                logController.AddLog(logDate, logType, userId);

                // Show success message
                MessageBox.Show("Uživatel byl úspěšně zaregistrován.", "Úspěch", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Close();
            }
            catch (Exception ex)
            {
                // Show error message
                if (ex.Message.Contains("UNIQUE KEY")) //Check for unique username
                {
                    MessageBox.Show("Zadané uživatelské jméno je již použité. Prosím, zvolte jiné uživatelské jméno.", "Chyba", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    MessageBox.Show($"Chyba: {ex.Message}", "Chyba", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
    }
}
