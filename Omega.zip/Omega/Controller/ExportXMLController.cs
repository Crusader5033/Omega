﻿using System;
using System.Data;
using System.IO;
using System.Xml;

namespace Omega.Controller
{
    public class ExportXMLController
    {
        public void ExportToXMLSluzby(string filePath)
        {
            try
            {
                Export export = new Export();
                DataTable dataTable = export.GetSluzby();

                using (XmlWriter writer = XmlWriter.Create(filePath))
                {
                    // Start writing the XML document
                    writer.WriteStartDocument();
                    writer.WriteStartElement("Sluzby");

                    // Write the data rows
                    foreach (DataRow row in dataTable.Rows)
                    {
                        writer.WriteStartElement("Sluzba");
                        foreach (DataColumn column in dataTable.Columns)
                        {
                            writer.WriteElementString(column.ColumnName, row[column].ToString());
                        }
                        writer.WriteEndElement(); // Close the Sluzba element
                    }

                    // End writing the XML document
                    writer.WriteEndElement();
                    writer.WriteEndDocument();
                }

                Console.WriteLine("XML file exported successfully.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error exporting XML file: {ex.Message}");
            }
        }


        public void ExportToXMLUsers(string filePath)
        {
            try
            {
                Export export = new Export();
                DataTable dataTable = export.GetUsers();

                using (XmlWriter writer = XmlWriter.Create(filePath))
                {
                    // Start writing the XML document
                    writer.WriteStartDocument();
                    writer.WriteStartElement("Uzivatel");

                    // Write the data rows
                    foreach (DataRow row in dataTable.Rows)
                    {
                        writer.WriteStartElement("Uzivatel");
                        foreach (DataColumn column in dataTable.Columns)
                        {
                            writer.WriteElementString(column.ColumnName, row[column].ToString());
                        }
                        writer.WriteEndElement(); // Close the Sluzba element
                    }

                    // End writing the XML document
                    writer.WriteEndElement();
                    writer.WriteEndDocument();
                }

                Console.WriteLine("XML file exported successfully.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error exporting XML file: {ex.Message}");
            }
        }
        public void ExportToXMLRole(string filePath)
        {
            try
            {
                Export export = new Export();
                DataTable dataTable = export.GetRole();

                using (XmlWriter writer = XmlWriter.Create(filePath))
                {
                    // Start writing the XML document
                    writer.WriteStartDocument();
                    writer.WriteStartElement("Role");

                    // Write the data rows
                    foreach (DataRow row in dataTable.Rows)
                    {
                        writer.WriteStartElement("Role");
                        foreach (DataColumn column in dataTable.Columns)
                        {
                            writer.WriteElementString(column.ColumnName, row[column].ToString());
                        }
                        writer.WriteEndElement(); // Close the Sluzba element
                    }

                    // End writing the XML document
                    writer.WriteEndElement();
                    writer.WriteEndDocument();
                }

                Console.WriteLine("XML file exported successfully.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error exporting XML file: {ex.Message}");
            }
        }
        public void ExportToXMLSpecializace(string filePath)
        {
            try
            {
                Export export = new Export();
                DataTable dataTable = export.GetSpecializace();

                using (XmlWriter writer = XmlWriter.Create(filePath))
                {
                    // Start writing the XML document
                    writer.WriteStartDocument();
                    writer.WriteStartElement("Specializace");

                    // Write the data rows
                    foreach (DataRow row in dataTable.Rows)
                    {
                        writer.WriteStartElement("Specializace");
                        foreach (DataColumn column in dataTable.Columns)
                        {
                            writer.WriteElementString(column.ColumnName, row[column].ToString());
                        }
                        writer.WriteEndElement(); // Close the Sluzba element
                    }

                    // End writing the XML document
                    writer.WriteEndElement();
                    writer.WriteEndDocument();
                }

                Console.WriteLine("XML file exported successfully.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error exporting XML file: {ex.Message}");
            }
        }

        public void ExportToXMLVojaci(string filePath)
        {
            try
            {
                Export export = new Export();
                DataTable dataTable = export.GetVojaci();

                using (XmlWriter writer = XmlWriter.Create(filePath))
                {
                    // Start writing the XML document
                    writer.WriteStartDocument();
                    writer.WriteStartElement("Vojak");

                    // Write the data rows
                    foreach (DataRow row in dataTable.Rows)
                    {
                        writer.WriteStartElement("Vojak");
                        foreach (DataColumn column in dataTable.Columns)
                        {
                            writer.WriteElementString(column.ColumnName, row[column].ToString());
                        }
                        writer.WriteEndElement(); // Close the Sluzba element
                    }

                    // End writing the XML document
                    writer.WriteEndElement();
                    writer.WriteEndDocument();
                }

                Console.WriteLine("XML file exported successfully.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error exporting XML file: {ex.Message}");
            }
        }

        public void ExportToXMLUtvary(string filePath)
        {
            try
            {
                Export export = new Export();
                DataTable dataTable = export.GetUtvary();

                using (XmlWriter writer = XmlWriter.Create(filePath))
                {
                    // Start writing the XML document
                    writer.WriteStartDocument();
                    writer.WriteStartElement("Utvar");

                    // Write the data rows
                    foreach (DataRow row in dataTable.Rows)
                    {
                        writer.WriteStartElement("Utvar");
                        foreach (DataColumn column in dataTable.Columns)
                        {
                            writer.WriteElementString(column.ColumnName, row[column].ToString());
                        }
                        writer.WriteEndElement(); // Close the Sluzba element
                    }

                    // End writing the XML document
                    writer.WriteEndElement();
                    writer.WriteEndDocument();
                }

                Console.WriteLine("XML file exported successfully.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error exporting XML file: {ex.Message}");
            }
        }

        public void ExportToXMLZkousky(string filePath)
        {
            try
            {
                Export export = new Export();
                DataTable dataTable = export.GetZkousky();

                using (XmlWriter writer = XmlWriter.Create(filePath))
                {
                    // Start writing the XML document
                    writer.WriteStartDocument();
                    writer.WriteStartElement("Zkouska");

                    // Write the data rows
                    foreach (DataRow row in dataTable.Rows)
                    {
                        writer.WriteStartElement("Zkouska");
                        foreach (DataColumn column in dataTable.Columns)
                        {
                            writer.WriteElementString(column.ColumnName, row[column].ToString());
                        }
                        writer.WriteEndElement(); // Close the Sluzba element
                    }

                    // End writing the XML document
                    writer.WriteEndElement();
                    writer.WriteEndDocument();
                }

                Console.WriteLine("XML file exported successfully.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error exporting XML file: {ex.Message}");
            }
        }

        public void ExportToXMLLogs(string filePath)
        {
            try
            {
                Export export = new Export();
                DataTable dataTable = export.GetLog();

                using (XmlWriter writer = XmlWriter.Create(filePath))
                {
                    // Start writing the XML document
                    writer.WriteStartDocument();
                    writer.WriteStartElement("Logy");

                    // Write the data rows
                    foreach (DataRow row in dataTable.Rows)
                    {
                        writer.WriteStartElement("Logy");
                        foreach (DataColumn column in dataTable.Columns)
                        {
                            writer.WriteElementString(column.ColumnName, row[column].ToString());
                        }
                        writer.WriteEndElement(); // Close the Sluzba element
                    }

                    // End writing the XML document
                    writer.WriteEndElement();
                    writer.WriteEndDocument();
                }

                Console.WriteLine("XML file exported successfully.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error exporting XML file: {ex.Message}");
            }
        }



    }
}
