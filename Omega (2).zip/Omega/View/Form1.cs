﻿using Omega.View;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Omega
{
    /// <summary>
    /// Main form of the application, providing options to select, insert, update, delete records, and export data.
    /// </summary>
    public partial class Form1 : Form
    {
        /// <summary>
        /// Constructor for the Form1 class.
        /// </summary>
        public Form1()
        {
            InitializeComponent();
            this.FormClosed += Form1_FormClosed;
        }

        // Event handler for the FormClosed event
        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit(); // Close the application when Form1 is closed
        }

        // Event handler for the Select button click event
        private void SelectBtn_Click(object sender, EventArgs e)
        {
            SelectForm selectForm = new SelectForm();
            selectForm.Show();
        }

        // Event handler for the Insert button click event
        private void InsertBtn_Click(object sender, EventArgs e)
        {
            InsertForm insertForm = new InsertForm();
            insertForm.Show();
        }

        // Event handler for the Delete button click event
        private void DeleteBtn_Click(object sender, EventArgs e)
        {
            DeleteForm deleteForm = new DeleteForm();
            deleteForm.Show();
        }

        // Event handler for the Update button click event
        private void UpdateBtn_Click(object sender, EventArgs e)
        {
            UpdateForm updateForm = new UpdateForm();
            updateForm.Show();
        }

        // Event handler for the Export to CSV button click event
        private void ExportCVSBtn_Click(object sender, EventArgs e)
        {
            ExportCSVForm exportForm = new ExportCSVForm();
            exportForm.Show();
        }

        // Event handler for the Export to XML button click event
        private void XMLExportBtn_Click(object sender, EventArgs e)
        {
            ExportXMLForm exportForm = new ExportXMLForm();
            exportForm.Show();
        }

        private void kryptonGroupBox1_Paint(object sender, PaintEventArgs e)
        {

        }

        // Event handler for the Logout button click event
        private void logOutBtn_Click(object sender, EventArgs e)
        {
            Login loginForm = new Login();
            this.Hide();
            loginForm.Show();
        }
    }
}
