﻿using Omega.Model;
using System;
using System.Data;

namespace Omega.Controller
{
    /// <summary>
    /// Represents a controller class for handling operations related to users.
    /// </summary>
    internal class UserController
    {
        private User u;

        /// <summary>
        /// Initializes a new instance of the <see cref="UserController"/> class.
        /// </summary>
        public UserController()
        {
            // Instantiates a User object to interact with user-related database operations.
            this.u = new User();
        }
        public void DeleteUser(int id)
        {
            // Calls the UpdateUtvarPusobiste method of the associated Utvar object to update the location or base of a specific military unit by ID.
            this.u.DeleteUser(id);
        }
        public void UpdateUserJmeno(int id, string jmeno)
        {
            // Calls the UpdateUtvarPusobiste method of the associated Utvar object to update the location or base of a specific military unit by ID.
            this.u.UpdateUserJmeno(id, jmeno);
        }
        public void UpdateUserPrijmeni(int id, string prijmeni)
        {
            // Calls the UpdateUtvarPusobiste method of the associated Utvar object to update the location or base of a specific military unit by ID.
            this.u.UpdateUserPrijmeni(id, prijmeni);
        }

        public void UpdateUserUsername(int id, string username)
        {
            // Calls the UpdateUtvarPusobiste method of the associated Utvar object to update the location or base of a specific military unit by ID.
            this.u.UpdateUserUsername(id, username);
        }

        public void UpdateUserEmail(int id, string email)
        {
            // Calls the UpdateUtvarPusobiste method of the associated Utvar object to update the location or base of a specific military unit by ID.
            this.u.UpdateUserEmail(id, email);
        }
        public void UpdateUserPassword(int id, string pass)
        {
            // Calls the UpdateUtvarPusobiste method of the associated Utvar object to update the location or base of a specific military unit by ID.
            this.u.UpdateUserPassword(id, pass);
        }

        public DataTable ListUsers()
        {
            // Calls the GetVojaci method of the associated Vojak object to retrieve soldier information.
            return this.u.GetUsers();
        }
        public bool ValidateUser(string username, string password, out int userId)
        {
            // Call the ValidateUser method of the associated User object
            return u.ValidateUser(username, password, out userId);
        }
        /// <summary>
        /// Adds a new user to the database.
        /// </summary>
        /// <param name="username">The username of the user to be added.</param>
        /// <param name="password">The password of the user to be added.</param>
        /// <param name="name">The name of the user to be added.</param>
        /// <param name="surname">The surname of the user to be added.</param>
        /// <param name="email">The email of the user to be added.</param>
        public int AddUser(string username, string password, string name, string surname, string email)
        {
            // Call the AddUser method of the associated User object to add a new user to the database and return the ID of the newly inserted user.
            return u.AddUser(username, password, name, surname, email);
        }
    }
}
