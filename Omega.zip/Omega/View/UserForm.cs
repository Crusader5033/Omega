﻿using Omega.Controller;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Omega.View
{
    public partial class UserForm : Form
    {
        private UserController userController;
        private LogController logController;
        private ExportCSVController exportCSVController;
        private ExportXMLController exportXMLController;
        public UserForm()
        {
            InitializeComponent();
           
            userController = new UserController();
            logController = new LogController();
            exportCSVController = new ExportCSVController();
            exportXMLController = new ExportXMLController();
            LoadUsersIntoDataGridView();
        }

        private void LoadUsersIntoDataGridView()
        {
            var userDataTable = userController.ListUsers();

            if (userDataTable != null)
            {
                UsersView.DataSource = userDataTable;
                
            }
            else
            {
                MessageBox.Show("Chyba při získávání dat z databáze.");
            }
        }

        private void addUserBtn_Click(object sender, EventArgs e)
        {
            Register registrationForm = new Register();
            registrationForm.Show();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void updateBtn_Click(object sender, EventArgs e)
        {
            try
            {
                if (UsersView.SelectedRows.Count > 0)
                {
                    int selectedUserId = Convert.ToInt32(UsersView.SelectedRows[0].Cells["id"].Value);

                    // Get the updated values from the textboxes
                    string updatedJmeno = NameBox.Text;
                    string updatedPrijmeni = SurnameBox.Text;
                    string updatedUsername = UsernameBox.Text;
                    string updatedEmail = emailBox.Text;
                    string updatedPassword = passwordBox.Text;

                    // Check if any textbox is filled
                    if (!string.IsNullOrEmpty(updatedJmeno) || !string.IsNullOrEmpty(updatedPrijmeni) ||
                        !string.IsNullOrEmpty(updatedUsername) || !string.IsNullOrEmpty(updatedEmail) ||
                        !string.IsNullOrEmpty(updatedPassword))
                    {
                        // Call the respective Update methods to update user attributes
                        if (!string.IsNullOrEmpty(updatedJmeno))
                        {
                            userController.UpdateUserJmeno(selectedUserId, updatedJmeno);
                        }
                        if (!string.IsNullOrEmpty(updatedPrijmeni))
                        {
                            userController.UpdateUserPrijmeni(selectedUserId, updatedPrijmeni);
                        }
                        if (!string.IsNullOrEmpty(updatedUsername))
                        {
                            userController.UpdateUserUsername(selectedUserId, updatedUsername);
                        }
                        if (!string.IsNullOrEmpty(updatedEmail))
                        {
                            userController.UpdateUserEmail(selectedUserId, updatedEmail);
                        }
                        if (!string.IsNullOrEmpty(updatedPassword))
                        {
                            userController.UpdateUserPassword(selectedUserId, updatedPassword);
                        }

                        // Reload the DataGridView to reflect the changes
                        LoadUsersIntoDataGridView();
                        MessageBox.Show("Uživatel byl aktualizován.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("Vyplňte alespoň jedno pole pro aktualizaci.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                else
                {
                    MessageBox.Show("Vyberte záznam.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Nastala chyba při aktualizaci uživatele.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        private void UsernameBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void passwordBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void emailBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void SurnameBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void NameBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void ExportXMLBtn_Click(object sender, EventArgs e)
        {
            try
            {
                // Create a new SaveFileDialog instance
                SaveFileDialog saveFileDialog = new SaveFileDialog();

                // Set properties for the file dialog
                saveFileDialog.Filter = "XML Files (*.xml)|*.xml"; // Set filter to show only XML files
                saveFileDialog.FileName = "dataUsers.xml"; // Default file name
                saveFileDialog.Title = "Export Users Data"; // Dialog title

                // Show the file dialog
                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    string filePath = saveFileDialog.FileName; // Get the selected file path

                    // Export data to XML using the selected file path
                    exportXMLController.ExportToXMLUsers(filePath);

                    // Show a success message
                    MessageBox.Show("Data exported successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                // Show an error message
                MessageBox.Show($"Error exporting data: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ExportCSVBtn_Click(object sender, EventArgs e)
        {
            try
            {
                // Create a new SaveFileDialog instance
                SaveFileDialog saveFileDialog = new SaveFileDialog();

                // Set properties for the file dialog
                saveFileDialog.Filter = "CSV Files (*.csv)|*.csv"; // Set filter to show only CSV files
                saveFileDialog.FileName = "dataUsers.csv"; // Default file name
                saveFileDialog.Title = "Export Users Data"; // Dialog title

                // Show the file dialog
                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    string filePath = saveFileDialog.FileName; // Get the selected file path

                    // Export data to CSV using the selected file path
                    exportCSVController.ExportToCSUsers(filePath);

                    // Show a success message
                    MessageBox.Show("Data exported successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                // Show an error message
                MessageBox.Show($"Error exporting data: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void deleteUserBtn_Click(object sender, EventArgs e)
        {
            try
            {
                if (UsersView.SelectedRows.Count > 0)
                {
                    int selectedUserId = Convert.ToInt32(UsersView.SelectedRows[0].Cells["id"].Value);

                    // Show a confirmation dialog
                    DialogResult result = MessageBox.Show("Opravdu chcete tohoto uživatele smazat?", "Potvrzení", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                    // If user confirms the deletion, proceed with deletion
                    if (result == DialogResult.Yes)
                    {
                        // First, delete logs associated with the user
                        logController.DeleteLog(selectedUserId);

                        // Then delete the user
                        userController.DeleteUser(selectedUserId);

                        // Reload the DataGridView to reflect the changes
                        LoadUsersIntoDataGridView();

                        MessageBox.Show("Uživatel byl odstraněn.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                else
                {
                    MessageBox.Show("Vyberte záznam.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Nastal problém při mazání uživatele.", "Chyba", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
