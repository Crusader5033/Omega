﻿using Omega.Model;
using System;
using System.Collections.Generic;
using System.Data;

namespace Omega.Controller
{
    /// <summary>
    /// Represents a controller class for handling operations related to roles.
    /// </summary>
    internal class RoleController
    {
        private Role r;

        /// <summary>
        /// Initializes a new instance of the <see cref="RoleController"/> class.
        /// </summary>
        public RoleController()
        {
            // Instantiates a Role object to interact with role-related database operations.
            this.r = new Role();
        }

        /// <summary>
        /// Retrieves a DataTable containing information about roles.
        /// </summary>
        /// <returns>A DataTable containing role information.</returns>
        public DataTable ListRole()
        {
            // Calls the GetRole method of the associated Role object to retrieve role information.
            return this.r.GetRole();
        }
        public void UpdateRoleNazev(int id, string newNazev)
        {
            // Calls the UpdateUtvarPusobiste method of the associated Utvar object to update the location or base of a specific military unit by ID.
            this.r.UpdateRoleNazev(id, newNazev);
        }
        /// <summary>
        /// Adds a new role to the database.
        /// </summary>
        /// <param name="name">The name of the role to be added.</param>
        public void AddRole(string name)
        {
            // Calls the AddRole method of the associated Role object to add a new role to the database.
            this.r.AddRole(name);
        }
    }
}
