﻿using Omega.Controller;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Omega.View
{
    /// <summary>
    /// Form for exporting data to CSV format for different entities.
    /// </summary>
    public partial class ExportCSVForm : Form
    {
        private ExportCSVController exportController;

        /// <summary>
        /// Constructor for the ExportCSVForm class.
        /// </summary>
        public ExportCSVForm()
        {
            InitializeComponent();
            exportController = new ExportCSVController();
        }

        // Event handler for exporting service data to CSV
        private void SluzbyExportBtn_Click(object sender, EventArgs e)
        {
            try
            {
                // Create a new instance of SaveFileDialog
                SaveFileDialog saveFileDialog = new SaveFileDialog();

                // Set properties for the file dialog
                saveFileDialog.Filter = "CSV files (*.csv)|*.csv"; // Set filter to show only CSV files
                saveFileDialog.FileName = "dataSluzby.csv"; // Default file name
                saveFileDialog.Title = "Export Service Data"; // Dialog title

                // Show the file dialog
                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    string filePath = saveFileDialog.FileName; // Get the selected file path

                    // Export data to CSV using the selected file path
                    exportController.ExportToCSVSluzby(filePath);

                    // Show a success message
                    MessageBox.Show("Data successfully exported.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                // Show an error message
                MessageBox.Show($"Error exporting data: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Event handler for exporting specialization data to CSV
        private void SpecializaceExportBtn_Click(object sender, EventArgs e)
        {
            try
            {
                // Create a new instance of SaveFileDialog
                SaveFileDialog saveFileDialog = new SaveFileDialog();

                // Set properties for the file dialog
                saveFileDialog.Filter = "CSV files (*.csv)|*.csv"; // Set filter to show only CSV files
                saveFileDialog.FileName = "dataSpecializace.csv"; // Default file name
                saveFileDialog.Title = "Export Specialization Data"; // Dialog title

                // Show the file dialog
                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    string filePath = saveFileDialog.FileName; // Get the selected file path

                    // Export data to CSV using the selected file path
                    exportController.ExportToCSVSpecializace(filePath);

                    // Show a success message
                    MessageBox.Show("Data successfully exported.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                // Show an error message
                MessageBox.Show($"Error exporting data: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Event handler for exporting examination data to CSV
        private void ZkouskyBtn_Click(object sender, EventArgs e)
        {
            try
            {
                // Create a new instance of SaveFileDialog
                SaveFileDialog saveFileDialog = new SaveFileDialog();

                // Set properties for the file dialog
                saveFileDialog.Filter = "CSV files (*.csv)|*.csv"; // Set filter to show only CSV files
                saveFileDialog.FileName = "dataZkousky.csv"; // Default file name
                saveFileDialog.Title = "Export Examination Data"; // Dialog title

                // Show the file dialog
                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    string filePath = saveFileDialog.FileName; // Get the selected file path

                    // Export data to CSV using the selected file path
                    exportController.ExportToCSVZkousky(filePath);

                    // Show a success message
                    MessageBox.Show("Data successfully exported.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                // Show an error message
                MessageBox.Show($"Error exporting data: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Event handler for exporting unit data to CSV
        private void UtvaryBtn_Click(object sender, EventArgs e)
        {
            try
            {
                // Create a new instance of SaveFileDialog
                SaveFileDialog saveFileDialog = new SaveFileDialog();

                // Set properties for the file dialog
                saveFileDialog.Filter = "CSV files (*.csv)|*.csv"; // Set filter to show only CSV files
                saveFileDialog.FileName = "dataUtvary.csv"; // Default file name
                saveFileDialog.Title = "Export Unit Data"; // Dialog title

                // Show the file dialog
                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    string filePath = saveFileDialog.FileName; // Get the selected file path

                    // Export data to CSV using the selected file path
                    exportController.ExportToCSVUtvar(filePath);

                    // Show a success message
                    MessageBox.Show("Data successfully exported.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                // Show an error message
                MessageBox.Show($"Error exporting data: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Event handler for exporting role data to CSV
        private void RoleBtn_Click(object sender, EventArgs e)
        {
            try
            {
                // Create a new instance of SaveFileDialog
                SaveFileDialog saveFileDialog = new SaveFileDialog();

                // Set properties for the file dialog
                saveFileDialog.Filter = "CSV files (*.csv)|*.csv"; // Set filter to show only CSV files
                saveFileDialog.FileName = "dataRole.csv"; // Default file name
                saveFileDialog.Title = "Export Role Data"; // Dialog title

                // Show the file dialog
                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    string filePath = saveFileDialog.FileName; // Get the selected file path

                    // Export data to CSV using the selected file path
                    exportController.ExportToCSVRole(filePath);

                    // Show a success message
                    MessageBox.Show("Data successfully exported.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                // Show an error message
                MessageBox.Show($"Error exporting data: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Event handler for exporting soldier data to CSV
        private void VojaciBtn_Click(object sender, EventArgs e)
        {
            try
            {
                // Create a new instance of SaveFileDialog
                SaveFileDialog saveFileDialog = new SaveFileDialog();

                // Set properties for the file dialog
                saveFileDialog.Filter = "CSV files (*.csv)|*.csv"; // Set filter to show only CSV files
                saveFileDialog.FileName = "dataVojaci.csv"; // Default file name
                saveFileDialog.Title = "Export Soldier Data"; // Dialog title

                // Show the file dialog
                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    string filePath = saveFileDialog.FileName; // Get the selected file path

                    // Export data to CSV using the selected file path
                    exportController.ExportToCSVojaci(filePath);

                    // Show a success message
                    MessageBox.Show("Data successfully exported.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                // Show an error message
                MessageBox.Show($"Error exporting data: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
