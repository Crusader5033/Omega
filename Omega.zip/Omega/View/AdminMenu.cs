﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Omega.View
{
    public partial class AdminMenu : Form
    {
        public AdminMenu()
        {
            InitializeComponent();
            this.FormClosed += AdminMenu_FormClosed;

        }
        private void AdminMenu_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit(); // Close the application when Form1 is closed
        }
        private void AdminMenu_Load(object sender, EventArgs e)
        {

        }

        

        private void UserBtn_Click(object sender, EventArgs e)
        {
            UserForm userForm = new UserForm();
            userForm.Show();
            return;
        }

        private void LogsBtn_Click(object sender, EventArgs e)
        {
            LogForm logForm = new LogForm();
            logForm.Show();
            return;
        }
    }
}
