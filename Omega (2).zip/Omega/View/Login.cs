﻿using Omega.Controller;
using System;
using System.Windows.Forms;

namespace Omega.View
{
    /// <summary>
    /// Represents the login form for the Omega application.
    /// </summary>
    public partial class Login : Form
    {
        private UserController userController; // Instance of UserController for user management
        private LogController logController; // Instance of LogController for logging
        private int loginAttempts; // Number of login attempts

        /// <summary>
        /// Initializes a new instance of the <see cref="Login"/> class.
        /// </summary>
        public Login()
        {
            InitializeComponent();
            this.FormClosed += LoginForm_FormClosed; // Close the application when login form is closed

            userController = new UserController();
            logController = new LogController();
            loginAttempts = 0;
        }

        private void LoginForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit(); // Close the application when login form is closed
        }

        private void registraceBtn_Click(object sender, EventArgs e)
        {
            Register registrationForm = new Register();
            registrationForm.Show();
        }

        /// <summary>
        /// Event handler for the login button click event.
        /// </summary>
        private void prihlasitBtn_Click(object sender, EventArgs e)
        {
            try
            {
                string username = UsernameBox.Text;
                string password = PasswordBox.Text;

                // Check if the login credentials match the administrator account
                if (username.ToLower() == "admin" && password.ToLower() == "admin")
                {
                    // Open the administrator menu form
                    AdminMenu adminMenuForm = new AdminMenu();
                    adminMenuForm.Show();
                    this.Hide();
                    return; // Exit the method since admin login credentials were used
                }

                // Validate username and password for regular users
                int userId;
                bool isValid = userController.ValidateUser(username, password, out userId);

                if (isValid)
                {
                    // Open the main form
                    Form1 mainForm = new Form1();
                    mainForm.Show();
                    this.Hide();

                    // Log the login event
                    DateTime logDate = DateTime.Now;
                    string logType = "Přihlášení";
                    logController.AddLog(logDate, logType, userId); // Pass the user ID here
                }
                else
                {
                    // Increment login attempts count
                    loginAttempts++;

                    // Log unsuccessful login attempt
                    DateTime logDate = DateTime.Now;
                    string logType = "Neúspěšné přihlášení";
                    logController.AddLog(logDate, logType, 1); // Pass 1 as user ID for unsuccessful login

                    // Show error message
                    MessageBox.Show("Nesprávné uživatelské jméno nebo heslo. Zkuste to prosím znovu.", "Chyba", MessageBoxButtons.OK, MessageBoxIcon.Error);

                    // If there have been 3 unsuccessful login attempts, lock the login form
                    if (loginAttempts >= 3)
                    {
                        prihlasitBtn.Enabled = false;
                        MessageBox.Show("Příliš mnoho neúspěšných pokusů o přihlášení. Kontaktujte podporu.", "Chyba", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {
                // Log the exception
                DateTime logDate = DateTime.Now;
                string logType = "Výjimka";
                logController.AddLog(logDate, logType, 1); // Pass 1 as user ID for exceptions

                // Show error message
                MessageBox.Show($"Došlo k chybě: {ex.Message}", "Chyba", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void Login_Load(object sender, EventArgs e)
        {

        }
        //After click send redirect to send email 
        private void kryptonLinkLabel1_LinkClicked(object sender, EventArgs e)
        {
            try
            {
                //Sending email
                System.Diagnostics.Process.Start("mailto:prochazka.dominik0503@gmail.com");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Došlo k chybě: {ex.Message}", "Chyba", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
