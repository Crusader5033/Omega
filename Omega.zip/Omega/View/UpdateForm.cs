﻿using Omega.Controller;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Omega.View
{
    public partial class UpdateForm : Form
    {
        private UtvarController utvarController = new UtvarController();
        private VojakController vojakController = new VojakController();
        private RoleController roleController = new RoleController();

        public UpdateForm()
        {
           
            InitializeComponent();
            LoadUtvaryIntoDataGridView();
            LoadRoleIntoDataGridView();
            LoadVojaciIntoDataGridView();
        }
        //Handles loading data do DataGridView for Utvary
        private void LoadUtvaryIntoDataGridView()
        {
            var utvarDataTable = utvarController.Listutvary();

            if (utvarDataTable != null)
            {
                utvarView.DataSource = utvarDataTable;
            }
            else
            {
                MessageBox.Show("Chyba při získávání dat z databáze.");
            }
        }
        //Handles loading data do DataGridView for Sluzby
        private void LoadVojaciIntoDataGridView()
        {
            var vojaciDataTable = vojakController.ListVojaci();
            if (vojaciDataTable != null)
            {
                VojakView.DataSource = vojaciDataTable;
            }
            else
            {
                MessageBox.Show("Chyba při získávání dat z databáze.");
            }
        }

        private void LoadRoleIntoDataGridView()
        {
            var vroleDataTable = roleController.ListRole();
            if (vroleDataTable != null)
            {
                RoleView.DataSource = vroleDataTable;
            }
            else
            {
                MessageBox.Show("Chyba při získávání dat z databáze.");
            }
        }

        private void utvarBtn_Click(object sender, EventArgs e)
        {
            try
            {
                if (utvarView.SelectedRows.Count > 0)
                {
                    int selectedUtvarId = Convert.ToInt32(utvarView.SelectedRows[0].Cells["id"].Value);

                    // Get the updated values from the textboxes
                    string updatedPusobiste = newPlaceBox.Text;
                    string updatedZamereni = ZamereniBox.Text;
                    string updatedNazev = NazevBox.Text;


                    // Check if any textbox is filled
                    if (!string.IsNullOrEmpty(updatedPusobiste) || !string.IsNullOrEmpty(updatedZamereni) || !string.IsNullOrEmpty(updatedNazev))
                    {
                        // Call the UpdateUtvarZamereni method to update the Zamereni attribute if ZamereniBox is filled
                        if (!string.IsNullOrEmpty(updatedZamereni))
                        {
                            utvarController.UpdateUtvarZamereni(selectedUtvarId, updatedZamereni);
                        }
                        if (!string.IsNullOrEmpty(updatedNazev))
                        {
                            utvarController.UpdateUtvarNazev(selectedUtvarId, updatedNazev); // Pass updatedNazev instead of updatedZamereni
                        }
                        // Call the UpdateUtvarPusobiste method to update the Pusobiste attribute if newPlaceBox is filled
                        if (!string.IsNullOrEmpty(updatedPusobiste))
                        {
                            utvarController.UpdateUtvarPusobiste(selectedUtvarId, updatedPusobiste);
                        }

                        // Reload the DataGridView to reflect the changes
                        LoadUtvaryIntoDataGridView();
                        MessageBox.Show("Utvar byl aktualizován.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("Vyplňte alespoň jedno pole pro aktualizaci.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                else
                {
                    MessageBox.Show("Vyberte záznam.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Nastala chyba při aktualizaci útvaru.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void sluzbaView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void newroleBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void ZamereniBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void VojakBtn_Click(object sender, EventArgs e)
        {
            try
            {
                if (VojakView.SelectedRows.Count > 0)
                {
                    int selectedVojakId = Convert.ToInt32(VojakView.SelectedRows[0].Cells["id"].Value);

                    // Get the updated values from the textboxes
                    string updatedJmeno = NameBox.Text;
                    string updatedPrijmeni = SurnameBox.Text;
                    bool updatedMise = false; // Default value

                    // Check if checkbox1 is checked
                    if (checkBox1.Checked)
                    {
                        updatedMise = true;
                    }
                    else if (checkBox2.Checked) // Check if checkbox2 is checked
                    {
                        updatedMise = false;
                    }
                    // Check if any textbox or checkbox is filled
                    if (!string.IsNullOrEmpty(updatedJmeno) || !string.IsNullOrEmpty(updatedPrijmeni) || checkBox1.Checked || checkBox2.Checked)
                    {
                        // Call the UpdateVojakJmeno method to update the Jmeno attribute if NameBox is filled
                        if (!string.IsNullOrEmpty(updatedJmeno))
                        {
                            vojakController.UpdateVojakJmeno(selectedVojakId, updatedJmeno);
                        }
                        // Call the UpdateVojakPrijmeni method to update the Prijmeni attribute if SurnameBox is filled
                        if (!string.IsNullOrEmpty(updatedPrijmeni))
                        {
                            vojakController.UpdateVojakPrijmeni(selectedVojakId, updatedPrijmeni);
                        }
                        // Call the UpdateVojakMise method to update the Zucastil_se_mise attribute based on the checkbox value
                        vojakController.UpdateVojakMise(selectedVojakId, updatedMise);

                        // Reload the DataGridView to reflect the changes
                        LoadVojaciIntoDataGridView();
                        MessageBox.Show("Voják byl aktualizován.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("Vyplňte alespoň jedno pole nebo zaškrtněte alespoň jeden checkbox pro aktualizaci.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                else
                {
                    MessageBox.Show("Vyberte záznam.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Nastala chyba při aktualizaci vojáka.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void SurnameBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void NameBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void VojakView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void tabPage3_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void RoleBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void RoleView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void RoleBtn_Click(object sender, EventArgs e)
        {
            try
            {
                if (RoleView.SelectedRows.Count > 0)
                {
                    int selectedRoleId = Convert.ToInt32(RoleView.SelectedRows[0].Cells["id"].Value);

                    // Get the updated value from the textbox
                    string updatedNazev = RoleBox.Text;

                    // Check if the textbox is filled
                    if (!string.IsNullOrEmpty(updatedNazev))
                    {
                        // Call the UpdateRoleNazev method to update the Nazev attribute
                        roleController.UpdateRoleNazev(selectedRoleId, updatedNazev);

                        // Reload the DataGridView to reflect the changes
                        LoadRoleIntoDataGridView();
                        MessageBox.Show("Role byla aktualizována.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("Vyplňte pole pro aktualizaci.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                else
                {
                    MessageBox.Show("Vyberte záznam.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Nastala chyba při aktualizaci role.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

    }
}
