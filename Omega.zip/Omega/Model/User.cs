﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace Omega.Model
{
    /// <summary>
    /// Represents a class for handling user-related operations in the database.
    /// </summary>
    internal class User
    {
        private SqlConnection connection;

        /// <summary>
        /// Initializes a new instance of the <see cref="User"/> class.
        /// </summary>
        public User()
        {
            // Establishes a database connection using the singleton pattern.
            connection = DatabaseSingleton.GetInstance();
        }


       


        public DataTable GetUsers()
        {
            DataTable selectTable = new DataTable();

            // Using a SqlCommand to execute a SELECT query.
            using (SqlCommand command = new SqlCommand("SELECT * FROM Users", connection))
            {
                // Using SqlDataAdapter to fill the DataTable with the results.
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                adapter.Fill(selectTable);
            }

            // Return the DataTable containing soldier information.
            return selectTable;
        }
        public bool ValidateUser(string username, string password, out int userId)
        {
            // SQL query to check if the username and password match
            string query = "SELECT id FROM Users WHERE username = @Username AND password = @Password";

            // Initialize userId to default value
            userId = -1;

            // Using SqlCommand to execute the query
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                // Adding parameters to prevent SQL injection
                command.Parameters.AddWithValue("@Username", username);
                command.Parameters.AddWithValue("@Password", password);

                // Opening the connection if not already open
                if (connection.State != System.Data.ConnectionState.Open)
                    connection.Open();

                // Execute the query and retrieve the user ID
                object result = command.ExecuteScalar();
                if (result != null)
                {
                    userId = (int)result;
                    return true; // Username and password are correct
                }
                else
                {
                    return false; // Username and password are incorrect
                }
            }
        }
        public int GetUserIdByUsername(string username)
        {
            int userId = 0;
            // Using a SqlCommand to execute a SELECT query.
            using (SqlCommand command = new SqlCommand("SELECT id FROM Users WHERE username = @Username", connection))
            {
                // Adding parameters to the command to prevent SQL injection.
                command.Parameters.AddWithValue("@Username", username);

                // Execute the query to retrieve the ID of the user.
                object result = command.ExecuteScalar();
                if (result != null)
                {
                    userId = Convert.ToInt32(result);
                }
            }
            return userId;
        }

        public void UpdateUserJmeno(int id, string updatedJmeno)
        {
            // Create a new connection using the singleton pattern.
            SqlConnection conn = DatabaseSingleton.GetInstance();

            // Using a SqlCommand to execute an UPDATE query for the operating location.
            using (SqlCommand command = new SqlCommand("UPDATE Users SET name=@newData WHERE id=@id", conn))
            {
                command.Parameters.AddWithValue("@newData", updatedJmeno);
                command.Parameters.AddWithValue("@id", id);
                command.ExecuteNonQuery();
            }
        }
        public void UpdateUserPrijmeni(int id, string updatedPrijmeni)
        {
            // Create a new connection using the singleton pattern.
            SqlConnection conn = DatabaseSingleton.GetInstance();

            // Using a SqlCommand to execute an UPDATE query for the operating location.
            using (SqlCommand command = new SqlCommand("UPDATE Users SET surname=@newData WHERE id=@id", conn))
            {
                command.Parameters.AddWithValue("@newData", updatedPrijmeni);
                command.Parameters.AddWithValue("@id", id);
                command.ExecuteNonQuery();
            }
        }
        public void UpdateUserEmail(int id, string email)
        {
            // Create a new connection using the singleton pattern.
            SqlConnection conn = DatabaseSingleton.GetInstance();

            // Using a SqlCommand to execute an UPDATE query for the operating location.
            using (SqlCommand command = new SqlCommand("UPDATE Users SET email=@newData WHERE id=@id", conn))
            {
                command.Parameters.AddWithValue("@newData", email);
                command.Parameters.AddWithValue("@id", id);
                command.ExecuteNonQuery();
            }
        }
        public void UpdateUserPassword(int id, string pass)
        {
            // Create a new connection using the singleton pattern.
            SqlConnection conn = DatabaseSingleton.GetInstance();

            // Using a SqlCommand to execute an UPDATE query for the operating location.
            using (SqlCommand command = new SqlCommand("UPDATE Users SET password=@newData WHERE id=@id", conn))
            {
                command.Parameters.AddWithValue("@newData", pass);
                command.Parameters.AddWithValue("@id", id);
                command.ExecuteNonQuery();
            }
        }
        public void UpdateUserUsername(int id, string username)
        {
            // Create a new connection using the singleton pattern.
            SqlConnection conn = DatabaseSingleton.GetInstance();

            // Using a SqlCommand to execute an UPDATE query for the operating location.
            using (SqlCommand command = new SqlCommand("UPDATE Users SET username=@newData WHERE id=@id", conn))
            {
                command.Parameters.AddWithValue("@newData", username);
                command.Parameters.AddWithValue("@id", id);
                command.ExecuteNonQuery();
            }
        }



        public void DeleteUser(int id)
        {
            // Using a SqlCommand to execute a DELETE query based on soldier ID.
            using (SqlCommand command = new SqlCommand("DELETE FROM Users WHERE id = @id", connection))
            {
                command.Parameters.AddWithValue("@id", id);
                command.ExecuteNonQuery();
            }
        }
        /// <summary>
        /// Adds a new user to the database.
        /// </summary>
        /// <param name="username">The username of the user.</param>
        /// <param name="password">The password of the user.</param>
        /// <param name="name">The name of the user.</param>
        /// <param name="surname">The surname of the user.</param>
        /// <param name="email">The email of the user.</param>
        public int AddUser(string username, string password, string name, string surname, string email)
        {
            // Using a SqlCommand to execute an INSERT query.
            using (SqlCommand command = new SqlCommand("INSERT INTO Users (username, password, name, surname, email) VALUES (@Username, @Password, @Name, @Surname, @Email); SELECT SCOPE_IDENTITY()", connection))
            {
                // Adding parameters to the command to prevent SQL injection.
                command.Parameters.AddWithValue("@Username", username);
                command.Parameters.AddWithValue("@Password", password);
                command.Parameters.AddWithValue("@Name", name);
                command.Parameters.AddWithValue("@Surname", surname);
                command.Parameters.AddWithValue("@Email", email);

                // Execute the query to add the user to the database and return the ID of the newly inserted user.
                return Convert.ToInt32(command.ExecuteScalar());
            }
        }
    }
}
