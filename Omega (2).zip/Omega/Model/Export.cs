﻿using System;
using System.Data;
using System.Data.SqlClient;
using Omega.Model;

namespace Omega.Controller
{
    public class Export
    {
        private SqlConnection connection;

        public Export()
        {
            connection = DatabaseSingleton.GetInstance();
        }

        public DataTable GetUsers()
        {
            DataTable selectTable = new DataTable();

            // Using a SqlCommand to execute a SELECT query.
            using (SqlCommand command = new SqlCommand("SELECT * FROM Users", connection))
            {
                // Using SqlDataAdapter to fill the DataTable with the results.
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                adapter.Fill(selectTable);
            }

            // Return the DataTable containing soldier information.
            return selectTable;
        }

        public DataTable GetZkousky()
        {
            DataTable selectTable = new DataTable();

            // Using a SqlCommand to execute a SELECT query with JOINs.
            using (SqlCommand command = new SqlCommand("SELECT Z.id AS ZkouskaID, V.Jmeno, V.Prijmeni, S.Nazev_specializace, Z.Datum_zkousky, Z.Misto_konani, Z.Vysledek_zkousky FROM Zkousky Z INNER JOIN Vojaci V ON Z.ID_Vojaka = V.id INNER JOIN Specializace S ON Z.ID_Specializace = S.id;", connection))
            {
                // Using SqlDataAdapter to fill the DataTable with the results.
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                adapter.Fill(selectTable);
            }

            // Return the DataTable containing test information with related soldier and specialization details.
            return selectTable;
        }
        public DataTable GetUtvary()
        {
            DataTable selectTable = new DataTable();

            // Using a SqlCommand to execute a SELECT query.
            using (SqlCommand command = new SqlCommand("SELECT * FROM Utvary", connection))
            {
                // Using SqlDataAdapter to fill the DataTable with the results.
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                adapter.Fill(selectTable);
            }

            // Return the DataTable containing unit information.
            return selectTable;
        }
        public DataTable GetRole()
        {
            // Create a DataTable to store the retrieved data.
            DataTable selectTable = new DataTable();

            // Using a SqlCommand to execute a SELECT query.
            using (SqlCommand command = new SqlCommand("SELECT * FROM Role", connection))
            {
                // Using SqlDataAdapter to fill the DataTable with the results.
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                adapter.Fill(selectTable);
            }

            // Return the DataTable containing role information.
            return selectTable;
        }
        public DataTable GetSluzby()
        {
            DataTable selectTable = new DataTable();

            // Using a SqlCommand to execute a SELECT query.
            using (SqlCommand command = new SqlCommand("SELECT * FROM Vojaci_S_Sluzbami", connection))
            {
                // Using SqlDataAdapter to fill the DataTable with the results.
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                adapter.Fill(selectTable);
            }

            // Return the DataTable containing service information with soldiers.
            return selectTable;
        }
        public DataTable GetVojaci()
        {
            DataTable selectTable = new DataTable();

            // Using a SqlCommand to execute a SELECT query.
            using (SqlCommand command = new SqlCommand("SELECT * FROM Vojaci", connection))
            {
                // Using SqlDataAdapter to fill the DataTable with the results.
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                adapter.Fill(selectTable);
            }

            // Return the DataTable containing soldier information.
            return selectTable;
        }
        public DataTable GetSpecializace()
        {
            DataTable selectTable = new DataTable();

            // Using a SqlCommand to execute a SELECT query.
            using (SqlCommand command = new SqlCommand("SELECT * FROM Specializace", connection))
            {
                // Using SqlDataAdapter to fill the DataTable with the results.
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                adapter.Fill(selectTable);
            }

            // Return the DataTable containing specialization information.
            return selectTable;
        }
        public DataTable GetLog()
        {
            DataTable selectTable = new DataTable();

            // Using a SqlCommand to execute a SELECT query.
            using (SqlCommand command = new SqlCommand("SELECT * FROM ListLogs", connection))
            {
                // Using SqlDataAdapter to fill the DataTable with the results.
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                adapter.Fill(selectTable);
            }

            // Return the DataTable containing service information with soldiers.
            return selectTable;
        }
    }
}
