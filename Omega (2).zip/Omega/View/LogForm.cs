﻿using Omega.Controller;
using System;
using System.Windows.Forms;

namespace Omega.View
{
    /// <summary>
    /// Represents the form for viewing and exporting logs in the Omega application.
    /// </summary>
    public partial class LogForm : Form
    {
        private LogController logController = new LogController(); // Instance of LogController for managing logs
        private ExportCSVController exportCSVController; // Instance of ExportCSVController for exporting logs to CSV
        private ExportXMLController exportXMLController; // Instance of ExportXMLController for exporting logs to XML

        /// <summary>
        /// Initializes a new instance of the <see cref="LogForm"/> class.
        /// </summary>
        public LogForm()
        {
            InitializeComponent();
            LoadLogsIntoDataGridView(); // Load logs into DataGridView
            exportCSVController = new ExportCSVController(); // Initialize ExportCSVController
            exportXMLController = new ExportXMLController(); // Initialize ExportXMLController
        }

        /// <summary>
        /// Loads logs into the DataGridView.
        /// </summary>
        private void LoadLogsIntoDataGridView()
        {
            var logsDataTable = logController.ListLogs(); // Retrieve logs data from the controller

            if (logsDataTable != null)
            {
                LogView.DataSource = logsDataTable; // Bind logs data to the DataGridView
            }
            else
            {
                MessageBox.Show("Chyba při získávání dat z databáze.", "Chyba", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LogView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            // Not used for now
        }

        /// <summary>
        /// Event handler for the Export to XML button click event.
        /// </summary>
        private void ExportXMLBtn_Click(object sender, EventArgs e)
        {
            try
            {
                // Create a new SaveFileDialog instance
                SaveFileDialog saveFileDialog = new SaveFileDialog();

                // Set properties for the file dialog
                saveFileDialog.Filter = "XML soubory (*.xml)|*.xml"; // Set filter to show only XML files
                saveFileDialog.FileName = "dataZaznamy.xml"; // Default file name
                saveFileDialog.Title = "Exportovat data záznamů"; // Dialog title

                // Show the file dialog
                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    string filePath = saveFileDialog.FileName; // Get the selected file path

                    // Export data to XML using the selected file path
                    exportXMLController.ExportToXMLLogs(filePath);

                    // Show a success message
                    MessageBox.Show("Data úspěšně exportována.", "Úspěch", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                // Show an error message
                MessageBox.Show($"Chyba při exportu dat: {ex.Message}", "Chyba", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// Event handler for the Export to CSV button click event.
        /// </summary>
        private void ExportCSVBtn_Click(object sender, EventArgs e)
        {
            try
            {
                // Create a new SaveFileDialog instance
                SaveFileDialog saveFileDialog = new SaveFileDialog();

                // Set properties for the file dialog
                saveFileDialog.Filter = "CSV soubory (*.csv)|*.csv"; // Set filter to show only CSV files
                saveFileDialog.FileName = "dataZaznamy.csv"; // Default file name
                saveFileDialog.Title = "Exportovat data záznamů"; // Dialog title

                // Show the file dialog
                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    string filePath = saveFileDialog.FileName; // Get the selected file path

                    // Export data to CSV using the selected file path
                    exportCSVController.ExportToCSVLogs(filePath);

                    // Show a success message
                    MessageBox.Show("Data úspěšně exportována.", "Úspěch", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                // Show an error message
                MessageBox.Show($"Chyba při exportu dat: {ex.Message}", "Chyba", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
