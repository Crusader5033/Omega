﻿using Omega.Model;
using System;
using System.Data;
using System.IO;

namespace Omega.Controller
{
    public class ExportCSVController
    {
        public void ExportToCSVSluzby(string filePath)
        {
            try
            {
                Export exportCSV = new Export();
                DataTable dataTable = exportCSV.GetSluzby();

                using (StreamWriter writer = new StreamWriter(filePath))
                {
                    // Write the column headers
                    foreach (DataColumn column in dataTable.Columns)
                    {
                        writer.Write($"{column.ColumnName},");
                    }
                    writer.WriteLine(); // Move to the next line after writing headers

                    // Write the data rows
                    foreach (DataRow row in dataTable.Rows)
                    {
                        foreach (var item in row.ItemArray)
                        {
                            writer.Write($"{item},");
                        }
                        writer.WriteLine(); // Move to the next line after writing a row
                    }
                }

                Console.WriteLine("CSV file exported successfully.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error exporting CSV file: {ex.Message}");
            }
        }
        public void ExportToCSVRole(string filePath)
        {
            try
            {
                Export exportCSV = new Export();
                DataTable dataTable = exportCSV.GetRole();

                using (StreamWriter writer = new StreamWriter(filePath))
                {
                    // Write the column headers
                    foreach (DataColumn column in dataTable.Columns)
                    {
                        writer.Write($"{column.ColumnName},");
                    }
                    writer.WriteLine(); // Move to the next line after writing headers

                    // Write the data rows
                    foreach (DataRow row in dataTable.Rows)
                    {
                        foreach (var item in row.ItemArray)
                        {
                            writer.Write($"{item},");
                        }
                        writer.WriteLine(); // Move to the next line after writing a row
                    }
                }

                Console.WriteLine("CSV file exported successfully.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error exporting CSV file: {ex.Message}");
            }
        }
        public void ExportToCSUsers(string filePath)
        {
            try
            {
                Export exportCSV = new Export();
                DataTable dataTable = exportCSV.GetUsers();

                using (StreamWriter writer = new StreamWriter(filePath))
                {
                    // Write the column headers
                    foreach (DataColumn column in dataTable.Columns)
                    {
                        writer.Write($"{column.ColumnName},");
                    }
                    writer.WriteLine(); // Move to the next line after writing headers

                    // Write the data rows
                    foreach (DataRow row in dataTable.Rows)
                    {
                        foreach (var item in row.ItemArray)
                        {
                            writer.Write($"{item},");
                        }
                        writer.WriteLine(); // Move to the next line after writing a row
                    }
                }

                Console.WriteLine("CSV file exported successfully.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error exporting CSV file: {ex.Message}");
            }
        }

        public void ExportToCSVojaci(string filePath)
        {
            try
            {
                Export exportCSV = new Export();
                DataTable dataTable = exportCSV.GetVojaci();

                using (StreamWriter writer = new StreamWriter(filePath))
                {
                    // Write the column headers
                    foreach (DataColumn column in dataTable.Columns)
                    {
                        writer.Write($"{column.ColumnName},");
                    }
                    writer.WriteLine(); // Move to the next line after writing headers

                    // Write the data rows
                    foreach (DataRow row in dataTable.Rows)
                    {
                        foreach (var item in row.ItemArray)
                        {
                            writer.Write($"{item},");
                        }
                        writer.WriteLine(); // Move to the next line after writing a row
                    }
                }

                Console.WriteLine("CSV file exported successfully.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error exporting CSV file: {ex.Message}");
            }
        }

        public void ExportToCSVSpecializace(string filePath)
        {
            try
            {
                Export exportCSV = new Export();
                DataTable dataTable = exportCSV.GetSpecializace();

                using (StreamWriter writer = new StreamWriter(filePath))
                {
                    // Write the column headers
                    foreach (DataColumn column in dataTable.Columns)
                    {
                        writer.Write($"{column.ColumnName},");
                    }
                    writer.WriteLine(); // Move to the next line after writing headers

                    // Write the data rows
                    foreach (DataRow row in dataTable.Rows)
                    {
                        foreach (var item in row.ItemArray)
                        {
                            writer.Write($"{item},");
                        }
                        writer.WriteLine(); // Move to the next line after writing a row
                    }
                }

                Console.WriteLine("CSV file exported successfully.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error exporting CSV file: {ex.Message}");
            }
        }
        public void ExportToCSVZkousky(string filePath)
        {
            try
            {
                Export exportCSV = new Export();
                DataTable dataTable = exportCSV.GetZkousky();

                using (StreamWriter writer = new StreamWriter(filePath))
                {
                    // Write the column headers
                    foreach (DataColumn column in dataTable.Columns)
                    {
                        writer.Write($"{column.ColumnName},");
                    }
                    writer.WriteLine(); // Move to the next line after writing headers

                    // Write the data rows
                    foreach (DataRow row in dataTable.Rows)
                    {
                        foreach (var item in row.ItemArray)
                        {
                            writer.Write($"{item},");
                        }
                        writer.WriteLine(); // Move to the next line after writing a row
                    }
                }

                Console.WriteLine("CSV file exported successfully.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error exporting CSV file: {ex.Message}");
            }
        }

        public void ExportToCSVUtvar(string filePath)
        {
            try
            {
                Export exportCSV = new Export();
                DataTable dataTable = exportCSV.GetUtvary();

                using (StreamWriter writer = new StreamWriter(filePath))
                {
                    // Write the column headers
                    foreach (DataColumn column in dataTable.Columns)
                    {
                        writer.Write($"{column.ColumnName},");
                    }
                    writer.WriteLine(); // Move to the next line after writing headers

                    // Write the data rows
                    foreach (DataRow row in dataTable.Rows)
                    {
                        foreach (var item in row.ItemArray)
                        {
                            writer.Write($"{item},");
                        }
                        writer.WriteLine(); // Move to the next line after writing a row
                    }
                }

                Console.WriteLine("CSV file exported successfully.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error exporting CSV file: {ex.Message}");
            }
        }


        public void ExportToCSVLogs(string filePath)
        {
            try
            {
                Export exportCSV = new Export();
                DataTable dataTable = exportCSV.GetLog();

                using (StreamWriter writer = new StreamWriter(filePath))
                {
                    // Write the column headers
                    foreach (DataColumn column in dataTable.Columns)
                    {
                        writer.Write($"{column.ColumnName},");
                    }
                    writer.WriteLine(); // Move to the next line after writing headers

                    // Write the data rows
                    foreach (DataRow row in dataTable.Rows)
                    {
                        foreach (var item in row.ItemArray)
                        {
                            writer.Write($"{item},");
                        }
                        writer.WriteLine(); // Move to the next line after writing a row
                    }
                }

                Console.WriteLine("CSV file exported successfully.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error exporting CSV file: {ex.Message}");
            }
        }

    }
}
