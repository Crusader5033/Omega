﻿using Omega.Controller;
using System;
using System.Windows.Forms;

namespace Omega.View
{
    /// <summary>
    /// Form for deleting records from the database.
    /// </summary>
    public partial class DeleteForm : Form
    {
        private readonly VojakController vojakController = new VojakController();
        private readonly SluzbaController sluzbaController = new SluzbaController();
        private readonly UtvarController utvarController = new UtvarController();
        private readonly ZkouskaController zkouskaController = new ZkouskaController();

        /// <summary>
        /// Constructor for the DeleteForm class.
        /// </summary>
        public DeleteForm()
        {
            InitializeComponent();
            LoadUtvaryIntoDataGridView();
            LoadSluzbyIntoDataGridView();
            LoadVojaciIntoDataGridView();
        }

        // Load units into the DataGridView
        private void LoadUtvaryIntoDataGridView()
        {
            var utvarDataTable = utvarController.Listutvary();

            if (utvarDataTable != null)
            {
                dataGridViewUtvar.DataSource = utvarDataTable;
            }
            else
            {
                MessageBox.Show("Error getting data from the database.");
            }
        }

        // Load services into the DataGridView
        private void LoadSluzbyIntoDataGridView()
        {
            var sluzbyDataTable = sluzbaController.ListSluzbyWithID();

            if (sluzbyDataTable != null)
            {
                dataGridViewSluzba.DataSource = sluzbyDataTable;
            }
            else
            {
                MessageBox.Show("Error getting data from the database.");
            }
        }

        // Load soldiers into the DataGridView
        private void LoadVojaciIntoDataGridView()
        {
            var vojaciDataTable = vojakController.ListVojaci();

            if (vojaciDataTable != null)
            {
                dataGridViewVojak.DataSource = vojaciDataTable;
            }
            else
            {
                MessageBox.Show("Error getting data from the database.");
            }
        }

        // Delete soldier button click event handler
        private void VojakBtn_Click(object sender, EventArgs e)
        {
            try
            {
                if (dataGridViewVojak.SelectedRows.Count > 0)
                {
                    int selectedVojakId = Convert.ToInt32(dataGridViewVojak.SelectedRows[0].Cells["id"].Value);

                    DialogResult result = MessageBox.Show("Do you really want to delete this record?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                    if (result == DialogResult.Yes)
                    {
                        sluzbaController.DeleteSluzbyByVojakId(selectedVojakId);
                        zkouskaController.DeleteZkouskaByVojakId(selectedVojakId);
                        vojakController.DeleteVojak(selectedVojakId);

                        LoadVojaciIntoDataGridView();

                        MessageBox.Show("Soldier has been removed.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                else
                {
                    MessageBox.Show("Select a record.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Delete service button click event handler
        private void sluzbaBtn_Click(object sender, EventArgs e)
        {
            try
            {
                if (dataGridViewSluzba.SelectedRows.Count > 0)
                {
                    int selectedSluzbaId = Convert.ToInt32(dataGridViewSluzba.SelectedRows[0].Cells["id"].Value);

                    DialogResult result = MessageBox.Show("Do you really want to delete this record?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                    if (result == DialogResult.Yes)
                    {
                        sluzbaController.DeleteSluzba(selectedSluzbaId);
                        LoadSluzbyIntoDataGridView();
                        MessageBox.Show("Record has been successfully removed.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                else
                {
                    MessageBox.Show("Select a record.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void dataGridViewUtvar_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridViewSluzba_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridViewVojak_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        private void DeleteForm_Load(object sender, EventArgs e)
        {

        }
        // Delete unit button click event handler
        private void utvarBtn_Click(object sender, EventArgs e)
        {
            try
            {
                if (dataGridViewUtvar.SelectedRows.Count > 0)
                {
                    int selectedUtvarId = Convert.ToInt32(dataGridViewUtvar.SelectedRows[0].Cells["id"].Value);

                    DialogResult result = MessageBox.Show("Do you really want to delete this unit?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                    if (result == DialogResult.Yes)
                    {
                        sluzbaController.DeleteSluzbyByVojakId(selectedUtvarId);
                        utvarController.DeleteUtvar(selectedUtvarId);
                        LoadUtvaryIntoDataGridView();
                        MessageBox.Show("Unit has been successfully removed.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                else
                {
                    MessageBox.Show("Select a record.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
