﻿namespace Omega.View
{
    partial class ExportCSVForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.SpecializaceExportBtn = new System.Windows.Forms.Button();
            this.SluzbyExportBtn = new System.Windows.Forms.Button();
            this.UtvaryBtn = new System.Windows.Forms.Button();
            this.RoleBtn = new System.Windows.Forms.Button();
            this.VojaciBtn = new System.Windows.Forms.Button();
            this.ZkouskyBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // SpecializaceExportBtn
            // 
            this.SpecializaceExportBtn.Location = new System.Drawing.Point(45, 33);
            this.SpecializaceExportBtn.Name = "SpecializaceExportBtn";
            this.SpecializaceExportBtn.Size = new System.Drawing.Size(176, 108);
            this.SpecializaceExportBtn.TabIndex = 0;
            this.SpecializaceExportBtn.Text = "Specializace";
            this.SpecializaceExportBtn.UseVisualStyleBackColor = true;
            this.SpecializaceExportBtn.Click += new System.EventHandler(this.SpecializaceExportBtn_Click);
            // 
            // SluzbyExportBtn
            // 
            this.SluzbyExportBtn.Location = new System.Drawing.Point(45, 204);
            this.SluzbyExportBtn.Name = "SluzbyExportBtn";
            this.SluzbyExportBtn.Size = new System.Drawing.Size(176, 108);
            this.SluzbyExportBtn.TabIndex = 1;
            this.SluzbyExportBtn.Text = "Sluzby";
            this.SluzbyExportBtn.UseVisualStyleBackColor = true;
            this.SluzbyExportBtn.Click += new System.EventHandler(this.SluzbyExportBtn_Click);
            // 
            // UtvaryBtn
            // 
            this.UtvaryBtn.Location = new System.Drawing.Point(323, 204);
            this.UtvaryBtn.Name = "UtvaryBtn";
            this.UtvaryBtn.Size = new System.Drawing.Size(176, 108);
            this.UtvaryBtn.TabIndex = 2;
            this.UtvaryBtn.Text = "Utvary";
            this.UtvaryBtn.UseVisualStyleBackColor = true;
            this.UtvaryBtn.Click += new System.EventHandler(this.UtvaryBtn_Click);
            // 
            // RoleBtn
            // 
            this.RoleBtn.Location = new System.Drawing.Point(323, 33);
            this.RoleBtn.Name = "RoleBtn";
            this.RoleBtn.Size = new System.Drawing.Size(176, 108);
            this.RoleBtn.TabIndex = 3;
            this.RoleBtn.Text = "Role";
            this.RoleBtn.UseVisualStyleBackColor = true;
            this.RoleBtn.Click += new System.EventHandler(this.RoleBtn_Click);
            // 
            // VojaciBtn
            // 
            this.VojaciBtn.Location = new System.Drawing.Point(587, 33);
            this.VojaciBtn.Name = "VojaciBtn";
            this.VojaciBtn.Size = new System.Drawing.Size(176, 108);
            this.VojaciBtn.TabIndex = 4;
            this.VojaciBtn.Text = "Vojaci";
            this.VojaciBtn.UseVisualStyleBackColor = true;
            this.VojaciBtn.Click += new System.EventHandler(this.VojaciBtn_Click);
            // 
            // ZkouskyBtn
            // 
            this.ZkouskyBtn.Location = new System.Drawing.Point(587, 204);
            this.ZkouskyBtn.Name = "ZkouskyBtn";
            this.ZkouskyBtn.Size = new System.Drawing.Size(176, 108);
            this.ZkouskyBtn.TabIndex = 5;
            this.ZkouskyBtn.Text = "Zkousky";
            this.ZkouskyBtn.UseVisualStyleBackColor = true;
            this.ZkouskyBtn.Click += new System.EventHandler(this.ZkouskyBtn_Click);
            // 
            // ExportCSVForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.ZkouskyBtn);
            this.Controls.Add(this.VojaciBtn);
            this.Controls.Add(this.RoleBtn);
            this.Controls.Add(this.UtvaryBtn);
            this.Controls.Add(this.SluzbyExportBtn);
            this.Controls.Add(this.SpecializaceExportBtn);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "ExportCSVForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ExportCSV";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button SpecializaceExportBtn;
        private System.Windows.Forms.Button SluzbyExportBtn;
        private System.Windows.Forms.Button UtvaryBtn;
        private System.Windows.Forms.Button RoleBtn;
        private System.Windows.Forms.Button VojaciBtn;
        private System.Windows.Forms.Button ZkouskyBtn;
    }
}