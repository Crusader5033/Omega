﻿using Omega.Controller;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Omega.View
{
    public partial class Register : Form
    {

        private UserController userController;
        private LogController logController;
        public Register()
        {
            InitializeComponent();

            userController = new UserController();
            logController = new LogController();
        }


        private void NameBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void SurnameBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void UsernameBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void PasswordBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void EmailBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void RegisterBtn_Click_1(object sender, EventArgs e)
        {
            try
            {
                // Získání informací o uživateli z formuláře
                string jmeno = NameBox.Text;
                string prijmeni = SurnameBox.Text;
                string uzivatelskeJmeno = UsernameBox.Text;
                string heslo = PasswordBox.Text;
                string email = EmailBox.Text; // Předpokládáme, že máte pole pro zadání e-mailu

                // Kontrola, zda jsou všechna pole vyplněna
                if (string.IsNullOrEmpty(jmeno) || string.IsNullOrEmpty(prijmeni) || string.IsNullOrEmpty(uzivatelskeJmeno) || string.IsNullOrEmpty(heslo) || string.IsNullOrEmpty(email))
                {
                    MessageBox.Show("Prosím, vyplňte všechna pole.", "Oznámení", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }

                // Přidání uživatele do databáze a získání ID nově vloženého uživatele
                int userId = userController.AddUser(uzivatelskeJmeno, heslo, jmeno, prijmeni, email);

                // Zaznamenání registrace uživatele
                DateTime logDate = DateTime.Now;
                string logType = "Registrace";
                logController.AddLog(logDate, logType, userId);

                // Zobrazení úspěšné zprávy
                MessageBox.Show("Uživatel byl úspěšně zaregistrován.", "Úspěch", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                // Zobrazení chybové zprávy
                MessageBox.Show($"Chyba: {ex.Message}", "Chyba", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

    }
}

