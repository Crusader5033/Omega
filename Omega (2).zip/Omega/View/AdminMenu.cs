﻿using System;
using System.Windows.Forms;

namespace Omega.View
{
    public partial class AdminMenu : Form
    {
        public AdminMenu()
        {
            InitializeComponent();
            this.FormClosed += AdminMenu_FormClosed;
        }

        // Event handler for form closed event
        private void AdminMenu_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit(); // Close the application when AdminMenu is closed
        }

        private void AdminMenu_Load(object sender, EventArgs e)
        {
            // Code to execute when the AdminMenu form is loaded
        }

        // Event handler for User button click
        private void UserBtn_Click(object sender, EventArgs e)
        {
            UserForm userForm = new UserForm();
            userForm.Show();
        }

        // Event handler for Logs button click
        private void LogsBtn_Click(object sender, EventArgs e)
        {
            LogForm logForm = new LogForm();
            logForm.Show();
        }

        // Event handler for logOut button click
        private void logOutBtn_Click(object sender, EventArgs e)
        {
            Login loginForm = new Login();
            this.Hide(); // Hide the current form
            loginForm.Show(); // Show the login form
        }
    }
}
