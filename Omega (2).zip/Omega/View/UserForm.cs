﻿using Omega.Controller;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Omega.View
{
    /// <summary>
    /// Represents the main form for managing users in the Omega application.
    /// </summary>
    public partial class UserForm : Form
    {
        private UserController userController; // Instance of UserController for user management
        private LogController logController; // Instance of LogController for log management
        private ExportCSVController exportCSVController; // Instance of ExportCSVController for CSV export
        private ExportXMLController exportXMLController; // Instance of ExportXMLController for XML export

        /// <summary>
        /// Initializes a new instance of the <see cref="UserForm"/> class.
        /// </summary>
        public UserForm()
        {
            InitializeComponent();

            // Initialize controller instances
            userController = new UserController();
            logController = new LogController();
            exportCSVController = new ExportCSVController();
            exportXMLController = new ExportXMLController();

            // Load users into the DataGridView
            LoadUsersIntoDataGridView();
        }

        /// <summary>
        /// Loads users from the database into the DataGridView.
        /// </summary>
        private void LoadUsersIntoDataGridView()
        {
            var userDataTable = userController.ListUsers();

            if (userDataTable != null)
            {
                UsersView.DataSource = userDataTable;
            }
            else
            {
                MessageBox.Show("Chyba při získávání dat z databáze.");
            }
        }

        private void addUserBtn_Click(object sender, EventArgs e)
        {
            // Open registration form for adding a new user
            Register registrationForm = new Register();
            registrationForm.Show();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            // Not implemented
        }

        private void updateBtn_Click(object sender, EventArgs e)
        {
            try
            {
                if (UsersView.SelectedRows.Count > 0)
                {
                    int selectedUserId = Convert.ToInt32(UsersView.SelectedRows[0].Cells["id"].Value);

                    // Get the updated values from the textboxes
                    string updatedJmeno = NameBox.Text;
                    string updatedPrijmeni = SurnameBox.Text;
                    string updatedUsername = UsernameBox.Text;
                    string updatedEmail = emailBox.Text;
                    string updatedPassword = passwordBox.Text;

                    // Check if any textbox is filled
                    if (!string.IsNullOrEmpty(updatedJmeno) || !string.IsNullOrEmpty(updatedPrijmeni) ||
                        !string.IsNullOrEmpty(updatedUsername) || !string.IsNullOrEmpty(updatedEmail) ||
                        !string.IsNullOrEmpty(updatedPassword))
                    {
                        // Call the respective Update methods to update user attributes
                        if (!string.IsNullOrEmpty(updatedJmeno))
                        {
                            userController.UpdateUserJmeno(selectedUserId, updatedJmeno);
                        }
                        if (!string.IsNullOrEmpty(updatedPrijmeni))
                        {
                            userController.UpdateUserPrijmeni(selectedUserId, updatedPrijmeni);
                        }
                        if (!string.IsNullOrEmpty(updatedUsername))
                        {
                            userController.UpdateUserUsername(selectedUserId, updatedUsername);
                        }
                        if (!string.IsNullOrEmpty(updatedEmail))
                        {
                            userController.UpdateUserEmail(selectedUserId, updatedEmail);
                        }
                        if (!string.IsNullOrEmpty(updatedPassword))
                        {
                            userController.UpdateUserPassword(selectedUserId, updatedPassword);
                        }

                        // Reload the DataGridView to reflect the changes
                        LoadUsersIntoDataGridView();
                        MessageBox.Show("Uživatel byl aktualizován.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("Vyplňte alespoň jedno pole pro aktualizaci.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                else
                {
                    MessageBox.Show("Vyberte záznam.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Nastala chyba při aktualizaci uživatele.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Event handlers for text changed events (not implemented)
        private void UsernameBox_TextChanged(object sender, EventArgs e) { }
        private void passwordBox_TextChanged(object sender, EventArgs e) { }
        private void emailBox_TextChanged(object sender, EventArgs e) { }
        private void SurnameBox_TextChanged(object sender, EventArgs e) { }
        private void NameBox_TextChanged(object sender, EventArgs e) { }

        private void ExportXMLBtn_Click(object sender, EventArgs e)
        {
            try
            {
                // Create a new SaveFileDialog instance
                SaveFileDialog saveFileDialog = new SaveFileDialog();

                // Set properties for the file dialog
                saveFileDialog.Filter = "XML soubory (*.xml)|*.xml"; // Set filter to show only XML files
                saveFileDialog.FileName = "dataUživatele.xml"; // Default file name
                saveFileDialog.Title = "Exportovat data uživatelů"; // Dialog title

                // Show the file dialog
                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    string filePath = saveFileDialog.FileName; // Get the selected file path

                    // Export data to XML using the selected file path
                    exportXMLController.ExportToXMLUsers(filePath);

                    // Show a success message
                    MessageBox.Show("Data úspěšně exportována.", "Úspěch", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                // Show an error message
                MessageBox.Show($"Chyba při exportu dat: {ex.Message}", "Chyba", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ExportCSVBtn_Click(object sender, EventArgs e)
        {
            try
            {
                // Create a new SaveFileDialog instance
                SaveFileDialog saveFileDialog = new SaveFileDialog();

                // Set properties for the file dialog
                saveFileDialog.Filter = "CSV soubory (*.csv)|*.csv"; // Set filter to show only CSV files
                saveFileDialog.FileName = "dataUživatele.csv"; // Default file name
                saveFileDialog.Title = "Exportovat data uživatelů"; // Dialog title

                // Show the file dialog
                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    string filePath = saveFileDialog.FileName; // Get the selected file path

                    // Export data to CSV using the selected file path
                    exportCSVController.ExportToCSUsers(filePath);

                    // Show a success message
                    MessageBox.Show("Data úspěšně exportována.", "Úspěch", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                // Show an error message
                MessageBox.Show($"Chyba při exportu dat: {ex.Message}", "Chyba", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void deleteUserBtn_Click(object sender, EventArgs e)
        {
            try
            {
                if (UsersView.SelectedRows.Count > 0)
                {
                    int selectedUserId = Convert.ToInt32(UsersView.SelectedRows[0].Cells["id"].Value);

                    // Show a confirmation dialog
                    DialogResult result = MessageBox.Show("Opravdu chcete tohoto uživatele smazat?", "Potvrzení", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                    // If user confirms the deletion, proceed with deletion
                    if (result == DialogResult.Yes)
                    {
                        // First, delete logs associated with the user
                        logController.DeleteLog(selectedUserId);

                        // Then delete the user
                        userController.DeleteUser(selectedUserId);

                        // Reload the DataGridView to reflect the changes
                        LoadUsersIntoDataGridView();

                        MessageBox.Show("Uživatel byl odstraněn.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                else
                {
                    MessageBox.Show("Vyberte záznam.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Nastal problém při mazání uživatele.", "Chyba", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
