﻿using Omega.Controller;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Omega.View
{
    public partial class Login : Form
    {
        private UserController userController;
        private LogController logController;
        private int loginAttempts;
        public Login()
        {
            InitializeComponent();
            userController = new UserController();
            logController = new LogController();
            loginAttempts = 0;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
        private void MainForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            // Když je hlavní formulář zavřen, ukončit aplikaci
            Application.Exit();
        }

        private void UsernameBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void PasswordBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void kryptonLabel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void registraceBtn_Click(object sender, EventArgs e)
        {
            Register registrationForm = new Register();
            registrationForm.Show();
        }

        private void prihlasitBtn_Click(object sender, EventArgs e)
        {
            try
            {
                string username = UsernameBox.Text;
                string password = PasswordBox.Text;

                // Kontrola, zda přihlašovací údaje odpovídají administrátorskému účtu
                if (username.ToLower() == "admin" && password.ToLower() == "admin")
                {
                    // Otevřít formulář pro administrátora
                    AdminMenu adminMenuForm = new AdminMenu();
                    adminMenuForm.Show();
                    this.Hide();
                    return; // Ukončit metodu, protože byly použity přihlašovací údaje admina
                }

                // Ověření uživatelského jména a hesla pro běžné uživatele
                int userId;
                bool isValid = userController.ValidateUser(username, password, out userId);

                if (isValid)
                {
                    // Otevřít hlavní formulář
                    Form1 mainForm = new Form1();
                    mainForm.Show();
                    this.Hide();

                    // Zaznamenat událost přihlášení
                    DateTime logDate = DateTime.Now;
                    string logType = "Přihlášení";
                    logController.AddLog(logDate, logType, userId); // Předat zde ID uživatele
                }
                else
                {
                    // Inkrementovat počet pokusů o přihlášení
                    loginAttempts++;

                    // Zaznamenat neúspěšný pokus o přihlášení
                    DateTime logDate = DateTime.Now;
                    string logType = "Neúspěšné přihlášení";
                    logController.AddLog(logDate, logType, 1); // Předat 0 jako ID uživatele pro neúspěšné přihlášení

                    // Zobrazit chybovou zprávu
                    MessageBox.Show("Nesprávné uživatelské jméno nebo heslo. Zkuste to prosím znovu.", "Chyba", MessageBoxButtons.OK, MessageBoxIcon.Error);

                    // Pokud bylo provedeno 3 neúspěšné pokusy o přihlášení, uzamknout formulář pro přihlášení
                    if (loginAttempts >= 3)
                    {
                        prihlasitBtn.Enabled = false;
                        MessageBox.Show("Příliš mnoho neúspěšných pokusů o přihlášení. Kontaktujte podporu.", "Chyba", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {
                // Zaznamenat výjimku
                DateTime logDate = DateTime.Now;
                string logType = "Výjimka";
                logController.AddLog(logDate, logType, 1); // Předat 0 jako ID uživatele pro výjimky

                // Zobrazit chybovou zprávu
                MessageBox.Show($"Došlo k chybě: {ex.Message}", "Chyba", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Login_Load(object sender, EventArgs e)
        {

        }
    }
}
