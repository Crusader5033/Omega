﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace Omega.Model
{
    /// <summary>
    /// Represents a class for handling log-related operations in the database.
    /// </summary>
    public class Log
    {
        private SqlConnection connection;

        /// <summary>
        /// Initializes a new instance of the <see cref="Log"/> class.
        /// </summary>
        public Log()
        {
            // Establishes a database connection using the singleton pattern.
            connection = DatabaseSingleton.GetInstance();
        }


        public void DeleteLogWithID(int id)
        {
            // Using a SqlCommand to execute a DELETE query based on soldier ID.
            using (SqlCommand command = new SqlCommand("DELETE FROM Logs WHERE user_id = @id", connection))
            {
                command.Parameters.AddWithValue("@id", id);
                command.ExecuteNonQuery();
            }
        }
        public DataTable GetLogs()
        {
            DataTable selectTable = new DataTable();

            // Using a SqlCommand to execute a SELECT query.
            using (SqlCommand command = new SqlCommand("SELECT * FROM ListLogs", connection))
            {
                // Using SqlDataAdapter to fill the DataTable with the results.
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                adapter.Fill(selectTable);
            }

            // Return the DataTable containing service information with soldiers.
            return selectTable;
        }
        /// <summary>
        /// Adds a new log entry to the database.
        /// </summary>
        /// <param name="logDate">The date of the log entry.</param>
        /// <param name="logType">The type of the log entry.</param>
        /// <param name="userId">The ID of the user associated with the log entry.</param>
        public void AddLog(DateTime logDate, string logType, int userId)
        {
            
            // Using a SqlCommand to execute an INSERT query.
            using (SqlCommand command = new SqlCommand("INSERT INTO Logs (log_date, log_type, user_id) VALUES (@LogDate, @LogType, @UserId)", connection))
            {
                // Adding parameters to the command to prevent SQL injection.
                command.Parameters.AddWithValue("@LogDate", logDate);
                command.Parameters.AddWithValue("@LogType", logType);
                command.Parameters.AddWithValue("@UserId", userId);

                // Execute the query to add the log entry to the database.
                command.ExecuteNonQuery();
            }
        }
    }
}
